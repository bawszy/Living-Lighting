# LivingLighting v2 — Fire TV build

**Status:** Source project prepared for building, not a compiled/tested v2 APK.

- App name in Fire TV launcher: **LivingLighting**
- Android application ID: `com.cj.livinglighting` (keeps existing Universal Ambient Light separate)
- Source fork licence: PolyForm Noncommercial 1.0.0; retain attribution/licences
- LED layout defaults (unchanged): shelves 0–239, TV 240–353, lamp 354–388; total 389
- Capture and mapping activation behaviour intentionally unchanged from v2 source

## Cloud build

Commit the contents of the `ual-source/` directory to the **root** of a private GitHub repository called `LivingLighting`, including the hidden `.github/` directory. On GitHub, open **Actions → LivingLighting - Fire TV APK → Run workflow**. The workflow builds `:app:assembleFullDebug` with Java 17, Android SDK 37 and NDK 27.2.12479018, and uploads artifact `LivingLighting-v2-FireTV-debug-APK` containing `app-full-debug.apk`. The workflow has not yet been run or verified.

The prior beta under the different `com.cj.ambientstudio` ID will remain separate, as will the working Universal Ambient Light app. Stop any other capture app before starting LivingLighting to prevent conflicting WLED commands.

## Fire TV installation

Install only after the build succeeds; for Downloader, publish the resulting `.apk` to a trusted direct HTTPS link. Fire TV capture permissions and real-time WLED connectivity require testing on the user's actual device. Protected streaming services such as Netflix are not supported by bypassing DRM.
