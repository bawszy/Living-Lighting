package com.vasmarfas.UniversalAmbientLight.common.util

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object PermissionHelper {
    private const val TAG = "PermissionHelper"
    private const val SHELL_CMD_TIMEOUT_SEC = 2L
    private val sShellGrantInFlight = AtomicBoolean(false)

    fun canDrawOverlays(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(context)) return true

            // На части телевизоров (например, Яндекс ТВ) Settings.canDrawOverlays возвращает false,
            // даже когда разрешение выдано через ADB или AppOps, поэтому спрашиваем AppOps напрямую.
            try {
                val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                val mode = appOps.checkOpNoThrow(
                    "android:system_alert_window", // AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW
                    Process.myUid(),
                    context.packageName
                )
                if (mode == AppOpsManager.MODE_ALLOWED) return true
            } catch (e: Exception) {
                Log.w(TAG, "AppOps check failed for SYSTEM_ALERT_WINDOW", e)
            }
            return false
        }
        return true
    }

    fun requestOverlayPermission(activity: Activity, requestCode: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(activity)) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + activity.packageName)
                )
                activity.startActivityForResult(intent, requestCode)
            } catch (e: Exception) {
                Log.e(TAG, "Cannot request overlay permission", e)
                openAppSettings(activity)
            }
        }
    }

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            return pm != null && pm.isIgnoringBatteryOptimizations(context.packageName)
        }
        return true
    }

    fun requestIgnoreBatteryOptimizations(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                intent.data = Uri.parse("package:" + activity.packageName)
                activity.startActivity(intent)
            } catch (e: Exception) {
                // На некоторых TV этот интент может быть недоступен — откроем общий экран исключений.
                Log.w(TAG, "Cannot request battery optimization exemption, opening settings", e)
                try {
                    activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (ignored: Exception) {
                    openAppSettings(activity)
                }
            }
        }
    }

    /**
     * Запрос записи экрана. Android 14+ по умолчанию предлагает показать одно приложение, и
     * подсветка тогда видит только его окно, а не весь экран. Конфигурация основного дисплея
     * оставляет в системном диалоге только весь экран.
     */
    fun screenCaptureIntent(manager: MediaProjectionManager): Intent {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            try {
                return manager.createScreenCaptureIntent(
                    MediaProjectionConfig.createConfigForDefaultDisplay()
                )
            } catch (e: LinkageError) {
                // Прошивка выдаёт себя за Android 14 (в Crashlytics это «Pixel 8 Pro»), а
                // MediaProjectionConfig во framework нет: запрос без конфигурации
                Log.w(TAG, "MediaProjectionConfig unavailable on SDK ${Build.VERSION.SDK_INT}", e)
            }
        }
        return manager.createScreenCaptureIntent()
    }

    fun hasProjectMediaPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                val mode = appOps.checkOpNoThrow(
                    "android:project_media",
                    Process.myUid(), context.packageName
                )
                return mode == AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) {
                Log.w(TAG, "Cannot check PROJECT_MEDIA permission", e)
            }
        }
        return true
    }

    fun openAppSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.data = Uri.parse("package:" + context.packageName)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Cannot open app settings", e)
            Toast.makeText(
                context,
                "Please open Settings > Apps > Hyperion Grabber manually",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun tryGrantProjectMediaViaShell(context: Context) {
        if (!sShellGrantInFlight.compareAndSet(false, true)) return

        Thread {
            try {
                val pkg = context.packageName
                val commands = arrayOf(
                    "appops set $pkg PROJECT_MEDIA allow",
                    "appops set $pkg android:project_media allow",
                    "appops set $pkg SYSTEM_ALERT_WINDOW allow",
                    "pm grant $pkg android.permission.SYSTEM_ALERT_WINDOW"
                )

                for (cmd in commands) {
                    var process: java.lang.Process? = null
                    try {
                        process = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
                        if (!process.waitFor(SHELL_CMD_TIMEOUT_SEC, TimeUnit.SECONDS)) {
                            try {
                                process.destroyForcibly()
                            } catch (_: Exception) {
                                // Процесс мог завершиться сам между таймаутом и попыткой убить.
                            }
                            continue
                        }
                        Log.d(TAG, "Executed: $cmd (exit: ${process.exitValue()})")
                    } catch (e: Exception) {
                        try {
                            process?.destroyForcibly()
                        } catch (_: Exception) {
                            // Команда и так не выполнилась; убираем процесс best-effort.
                        }
                        Log.w(TAG, "Command failed: $cmd")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Shell commands failed", e)
            } finally {
                sShellGrantInFlight.set(false)
            }
        }.apply { isDaemon = true; name = "ShellGrantAsync" }.start()
    }

    fun showFullPermissionDialog(activity: Activity, onRetry: Runnable?) {
        val deviceInfo = "Device: " + Build.MANUFACTURER + " " + Build.MODEL

        val message = """
            Screen recording permission could not be obtained.
            
            Your TV may be blocking the permission dialog.
            
            SOLUTIONS:
            
            1. OVERLAY PERMISSION:
               Settings > Apps > Special access > Display over other apps
            
            2. APP PERMISSIONS:
               Settings > Apps > Hyperion Grabber > Permissions
            
            3. AUTO-START (TCL/Smart TVs):
               Settings > Privacy > Special app access > Auto-start
               OR Settings > Apps > App management
            
            4. BATTERY OPTIMIZATION:
               Settings > Apps > Special access > Battery optimization
            
            5. ADB COMMAND (requires computer):
               adb shell appops set ${activity.packageName} PROJECT_MEDIA allow
            
            $deviceInfo
            """.trimIndent()

        AlertDialog.Builder(activity)
            .setTitle("Permission Required")
            .setMessage(message)
            .setPositiveButton("Open App Settings") { _, _ -> openAppSettings(activity) }
            .setNeutralButton("Try Overlay") { _, _ ->
                requestOverlayPermission(activity, 999)
            }
            .setNegativeButton("Retry") { _, _ ->
                tryGrantProjectMediaViaShell(activity)
                if (onRetry != null) {
                    activity.window.decorView.postDelayed({
                        onRetry.run()
                    }, 1000)
                }
            }
            .setCancelable(true)
            .show()
    }
}
