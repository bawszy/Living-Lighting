package com.vasmarfas.UniversalAmbientLight.ui.studio

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vasmarfas.UniversalAmbientLight.common.studio.StudioCaptureTrials
import com.vasmarfas.UniversalAmbientLight.common.studio.StudioConfig
import com.vasmarfas.UniversalAmbientLight.common.studio.StudioEffects
import com.vasmarfas.UniversalAmbientLight.common.studio.StudioFrameMonitor
import com.vasmarfas.UniversalAmbientLight.common.studio.StudioSegment
import com.vasmarfas.UniversalAmbientLight.common.studio.StudioStore
import com.vasmarfas.UniversalAmbientLight.common.util.Preferences

private val ink = Color(0xFF09111F)
private val panel = Color(0xFF141E30)
private val subtle = Color(0xFF9BAAC2)
private val neon = Color(0xFF66DED7)
private val violet = Color(0xFFA9A2FF)
private val borderTint = Color(0xFF293852)
private val snow = Color(0xFFF3F8FE)
private val presets = listOf(
    "Full screen" to intArrayOf(0, 0, 100, 100),
    "Left half" to intArrayOf(0, 0, 50, 100),
    "Right half" to intArrayOf(50, 0, 100, 100),
    "Top" to intArrayOf(0, 0, 100, 25),
    "Bottom" to intArrayOf(0, 75, 100, 100),
    "Centre" to intArrayOf(25, 25, 75, 75),
    "Upper right" to intArrayOf(50, 0, 100, 50),
    "Lower left" to intArrayOf(0, 50, 50, 100)
)

/** Everything in this screen is opt-in. Capture methods and preferences are never changed here. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(onBackClick: () -> Unit, onCaptureSettingsClick: () -> Unit = {}) {
    val context = LocalContext.current
    val prefs = remember(context) { Preferences(context) }
    var config by remember { mutableStateOf(StudioStore.read(prefs.preferences)) }
    var enabled by remember { mutableStateOf(StudioStore.enabled(prefs.preferences)) }
    var selectedId by remember { mutableStateOf(config.segments.firstOrNull()?.id ?: 1) }
    var totalText by remember { mutableStateOf(config.total.toString()) }
    var presetName by remember { mutableStateOf("") }
    var savedPresets by remember { mutableStateOf(StudioStore.presets(prefs.preferences)) }
    var trialActive by remember { mutableStateOf(StudioCaptureTrials.active(prefs.preferences)) }
    var holdBlack by remember { mutableStateOf(StudioStore.holdBlack(prefs.preferences)) }
    var diagnostics by remember { mutableStateOf(StudioStore.diagnostics(prefs.preferences)) }
    var limit by remember { mutableStateOf(StudioStore.blackLimit(prefs.preferences)) }
    var monitor by remember { mutableStateOf(StudioFrameMonitor.snapshot()) }
    var selectedTest by remember { mutableStateOf(-1) }
    var notice by remember { mutableStateOf("Your existing capture profile is unchanged.") }
    val selected = config.segments.firstOrNull { it.id == selectedId }

    DisposableEffect(prefs) { onDispose { StudioStore.test(prefs.preferences, -1) } }

    fun save(): Boolean {
        val next = config.copy(total = totalText.toIntOrNull() ?: -1)
        val error = StudioStore.save(prefs.preferences, next)
        if (error != null) { notice = error; return false }
        config = next
        notice = "Saved • ${next.segments.size} segments • ${next.total} LEDs"
        return true
    }
    fun edit(segment: StudioSegment) {
        config = config.copy(segments = config.segments.map { if (it.id == segment.id) segment else it })
        notice = "Changes not yet saved"
    }
    fun add() {
        val free = firstAvailable(config)
        if (free == null) { notice = "All LEDs assigned. Split an existing segment."; return }
        val id = (config.segments.maxOfOrNull { it.id } ?: 0) + 1
        config = config.copy(segments = config.segments + StudioSegment(id, "New zone", free, free + 1))
        selectedId = id
        notice = "New zone created. Set the LED range and save."
    }
    fun split() {
        val s = selected ?: return
        if (s.length < 2) return
        val midpoint = s.start + s.length / 2
        val nextId = (config.segments.maxOfOrNull { it.id } ?: 0) + 1
        config = config.copy(segments = config.segments.flatMap {
            if (it.id == s.id) listOf(s.copy(stop = midpoint, name = "${s.name} A"),
                s.copy(id = nextId, start = midpoint, name = "${s.name} B")) else listOf(it)
        })
        selectedId = nextId
        notice = "Split into two independent zones. Save to apply."
    }

    Scaffold(
        containerColor = ink,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("LIVINGLIGHTING", color = snow, fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp)
                        Text("CJ EDITION   /   LIGHTING CONTROL", color = subtle, fontSize = 11.sp,
                            letterSpacing = 1.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { StudioStore.test(prefs.preferences, -1); onBackClick() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = snow)
                    }
                },
                actions = {
                    Text(if (enabled) "● CUSTOM MAPPING ON" else "● ORIGINAL CAPTURE SAFE",
                        color = if (enabled) neon else subtle,
                        modifier = Modifier.padding(end = 24.dp), fontSize = 13.sp)
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ink)
            )
        }
    ) { inner ->
        BoxWithConstraints(Modifier.fillMaxSize().padding(inner)
            .background(Brush.verticalGradient(listOf(ink, Color(0xFF0C1629))))) {
            val widescreen = maxWidth >= 800.dp
            val main = @Composable {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    StudioPanel("SYSTEM", "Capture stays as you already configured it") {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text("Independent LED mapping", color = snow, fontWeight = FontWeight.Bold)
                                Caption(if (enabled) "Active • custom zones drive WLED" else "Off • original ambient app behaviour")
                            }
                            Switch(checked = enabled, onCheckedChange = { next ->
                                if (!next) {
                                    StudioStore.setEnabled(prefs.preferences, false)
                                    enabled = false
                                    notice = "Original mapping restored"
                                } else if (save()) {
                                    StudioStore.setEnabled(prefs.preferences, true)
                                    enabled = true
                                }
                            })
                        }
                        LedOverview(config)
                        Caption("One capture, one ordered 389-pixel WLED DDP stream. No wiring changes.")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            NumericField("Total LEDs", totalText, { totalText = it }, Modifier.weight(1f))
                            Button(onClick = { save() }) { Text("Save") }
                        }
                    }
                    StudioPanel("ZONES", "Select any range • map each independently") {
                        config.segments.forEach { segment ->
                            val focused = segment.id == selectedId
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = { selectedId = segment.id },
                                    border = BorderStroke(if (focused) 2.dp else 1.dp,
                                        if (focused) neon else borderTint),
                                    modifier = Modifier.weight(1f)) {
                                    Text("${segment.name}  ·  ${segment.start+1}–${segment.stop}",
                                        color = if (focused) neon else snow,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Checkbox(checked = segment.enabled, onCheckedChange = { edit(segment.copy(enabled = it)) })
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { add() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF286D74))) {
                                Text("+ Zone")
                            }
                            OutlinedButton(onClick = { split() }, enabled = (selected?.length ?: 0) > 1) {
                                Text("Split")
                            }
                            TextButton(onClick = {
                                config = config.copy(segments = config.segments.filterNot { it.id == selectedId })
                                selectedId = config.segments.firstOrNull()?.id ?: -1
                                notice = "Zone deleted; save to apply"
                            }, enabled = selected != null && config.segments.size > 1) {
                                Text("Delete", color = Color(0xFFFFA8A8))
                            }
                        }
                    }
                    StudioPanel("SCENES", "Recall your layouts and effects") {
                        OutlinedTextField(value = presetName, onValueChange = { presetName = it.take(48) },
                            singleLine = true, label = { Text("Name this scene") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            val candidate = config.copy(total = totalText.toIntOrNull() ?: -1)
                            if (presetName.isBlank()) notice = "Enter a scene name first"
                            else if (candidate.error() != null) notice = candidate.error() ?: "Invalid mapping"
                            else {
                                StudioStore.savePreset(prefs.preferences, presetName, candidate)
                                savedPresets = StudioStore.presets(prefs.preferences)
                                notice = "Scene saved: $presetName"
                            }
                        }) { Text("Save scene") }
                        savedPresets.forEach { name ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                                    StudioStore.loadPreset(prefs.preferences, name)?.let {
                                        config = it; totalText = it.total.toString()
                                        selectedId = it.segments.firstOrNull()?.id ?: -1
                                        notice = "Loaded '$name'. Press Save to apply."
                                    }
                                }) { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                                TextButton(onClick = {
                                    StudioStore.deletePreset(prefs.preferences, name)
                                    savedPresets = StudioStore.presets(prefs.preferences)
                                }) { Text("Remove", color = subtle) }
                            }
                        }
                    }
                }
            }
            val detail = @Composable {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (selected != null) {
                        StudioPanel("ZONE INSPECTOR", "${selected.name}   •   ${selected.length} individually-addressable LEDs") {
                            OutlinedTextField(value = selected.name,
                                onValueChange = { edit(selected.copy(name = it.take(40))) },
                                singleLine = true, label = { Text("Zone name") }, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                NumberSetting("First LED", selected.start + 1, 1..2048, Modifier.weight(1f)) {
                                    edit(selected.copy(start = it - 1))
                                }
                                NumberSetting("Last LED", selected.stop, 1..2048, Modifier.weight(1f)) {
                                    edit(selected.copy(stop = it))
                                }
                            }
                            Caption("Physical LED ranges cannot overlap. Screen regions can overlap freely.")
                            Text("CAPTURE REGION", color = neon, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            ScreenRegionPreview(selected)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Choice("Screen area", "Select", presets.map { it.first }, Modifier.weight(1f)) { name ->
                                    presets.firstOrNull { it.first == name }?.second?.let { rect ->
                                        edit(selected.copy(left=rect[0],top=rect[1],right=rect[2],bottom=rect[3]))
                                    }
                                }
                                Choice("Sampling", selected.mapping, listOf("average","horizontal","vertical","perimeter",
                                    "top","right","bottom","left"), Modifier.weight(1f)) {
                                    edit(selected.copy(mapping = it))
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                NumberSetting("Left %", selected.left, 0..99, Modifier.weight(1f)) { edit(selected.copy(left = it)) }
                                NumberSetting("Top %", selected.top, 0..99, Modifier.weight(1f)) { edit(selected.copy(top = it)) }
                                NumberSetting("Right %", selected.right, 1..100, Modifier.weight(1f)) { edit(selected.copy(right = it)) }
                                NumberSetting("Bottom %", selected.bottom, 1..100, Modifier.weight(1f)) { edit(selected.copy(bottom = it)) }
                            }
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Reverse LED direction", color = snow)
                                Switch(checked = selected.reverse, onCheckedChange = { edit(selected.copy(reverse = it)) })
                            }
                        }
                        StudioPanel("COLOUR + MOTION", "31 available modes • independent per zone") {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Choice("Effect", selected.mode, StudioEffects.modes, Modifier.weight(1f)) {
                                    edit(selected.copy(mode = it))
                                }
                                NumberSetting("Speed", selected.speed, 1..100, Modifier.weight(1f)) { edit(selected.copy(speed = it)) }
                                NumberSetting("Intensity", selected.intensity, 0..100, Modifier.weight(1f)) { edit(selected.copy(intensity = it)) }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                NumberSetting("Brightness %", selected.brightness, 0..100, Modifier.weight(1f)) { edit(selected.copy(brightness = it)) }
                                NumberSetting("Saturation %", selected.saturation, 0..200, Modifier.weight(1f)) { edit(selected.copy(saturation = it)) }
                                NumberSetting("Smoothing %", selected.smoothing, 0..95, Modifier.weight(1f)) { edit(selected.copy(smoothing = it)) }
                            }
                            Caption("Effect colours are 6-digit RGB hex (e.g. FF6600).")
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                HexColorSetting("Primary", selected.color, Modifier.weight(1f)) { edit(selected.copy(color = it)) }
                                HexColorSetting("Secondary", selected.secondaryColor, Modifier.weight(1f)) { edit(selected.copy(secondaryColor = it)) }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    selectedTest = if (selectedTest == selected.id) -1 else selected.id
                                    StudioStore.test(prefs.preferences, selectedTest)
                                }, colors=ButtonDefaults.buttonColors(containerColor = Color(0xFF286D74))) {
                                    Text(if (selectedTest == selected.id) "Stop zone test" else "Identify LEDs")
                                }
                                OutlinedButton(onClick = { save() }) { Text("Save mapping") }
                            }
                            Caption("Identify lights the selected zone white while screen capture runs; all other LEDs are off.")
                        }
                    }
                    StudioPanel("COMPATIBILITY LAB", "Optional experiments • original capture defaults preserved") {
                        Caption("These controls cannot bypass DRM on Netflix or Prime Video. " +
                            "They are for checking capture behaviour and handling temporarily black frames.")
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text("Capture diagnostics", color = snow, fontWeight = FontWeight.Bold)
                                Caption("Read black-pixel percentage of captured frames")
                            }
                            Switch(checked = diagnostics, onCheckedChange = {
                                diagnostics = it; StudioStore.setDiagnostics(prefs.preferences, it)
                            })
                        }
                        if (diagnostics) {
                            OutlinedButton(onClick = { monitor = StudioFrameMonitor.snapshot() }) { Text("Refresh capture readings") }
                            Text("${monitor.width} × ${monitor.height}  ·  ${monitor.frames} frames  ·  ${monitor.blackPercent}% dark",
                                color = neon)
                            Caption("100% dark may mean a protected/hidden video layer—or simply a black scene.")
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text("Hold last colours on black", color = snow, fontWeight = FontWeight.Bold)
                                Caption("Experimental. Useful for brief blank frames; not a video-unlock setting.")
                            }
                            Switch(checked = holdBlack, onCheckedChange = {
                                holdBlack = it; StudioStore.setHoldBlack(prefs.preferences, it)
                            })
                        }
                        if (holdBlack) {
                            NumberSetting("Hold if dark pixels reach %", limit, 75..100, Modifier.fillMaxWidth(0.55f)) {
                                limit = it; StudioStore.setBlackLimit(prefs.preferences, it)
                            }
                            Caption("Disable if dark scenes freeze your lights at an old colour.")
                        }
                        HorizontalDivider(color = borderTint)
                        Text("ONE-CLICK CAPTURE TRIALS", color = violet, fontSize = 12.sp,
                            letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
                        Caption("Tests frame rate and input resolution only. Start one trial, restart capture, " +
                            "compare the same video, then restore your exact previous values.")
                        StudioCaptureTrials.options.chunked(2).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()) {
                                row.forEach { trial ->
                                    OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                                        StudioCaptureTrials.start(prefs.preferences, trial)
                                        trialActive = true
                                        notice = "Trial: ${trial.label} (${trial.fps}fps / ${trial.quality}px). Restart screen capture."
                                    }) { Text(trial.label, maxLines = 1) }
                                }
                            }
                        }
                        Button(enabled = trialActive, onClick = {
                            StudioCaptureTrials.restore(prefs.preferences)
                            trialActive = false
                            notice = "Original frame rate and capture quality restored. Restart capture."
                        }) { Text("Restore original capture values") }
                        OutlinedButton(onClick = onCaptureSettingsClick) { Text("Open original capture settings") }
                        Caption("Try the app's existing capture methods there one at a time. " +
                            "Trials change FPS/quality only after you press a button; they do not alter the capture method or access permissions.")
                    }
                    Text(notice, color = neon, fontSize = 13.sp, modifier = Modifier.padding(6.dp))
                }
            }
            if (widescreen) {
                Row(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    Column(Modifier.weight(0.39f).fillMaxHeight().verticalScroll(rememberScrollState())) { main() }
                    Column(Modifier.weight(0.61f).fillMaxHeight().verticalScroll(rememberScrollState())) { detail() }
                }
            } else {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { main(); detail() }
            }
        }
    }
}

@Composable
private fun StudioPanel(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = panel),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, borderTint),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, color = violet, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp, fontSize = 13.sp)
            Text(subtitle, color = subtle, fontSize = 12.sp)
            HorizontalDivider(color = borderTint)
            content()
        }
    }
}

@Composable
private fun Caption(text: String) {
    Text(text, color = subtle, fontSize = 12.sp, lineHeight = 17.sp)
}

@Composable
private fun LedOverview(config: StudioConfig) {
    Row(Modifier.fillMaxWidth().height(15.dp).background(ink, RoundedCornerShape(10.dp)),
        horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        val palette = listOf(neon, violet, Color(0xFFFFBC77), Color(0xFFED83B5), Color(0xFF62A6FF))
        val covered = config.segments.sortedBy { it.start }
        var at = 0
        covered.forEachIndexed { i, s ->
            if (s.start > at) Box(Modifier.weight((s.start-at).toFloat()).fillMaxHeight().background(borderTint))
            Box(Modifier.weight(s.length.coerceAtLeast(1).toFloat()).fillMaxHeight()
                .background(if (s.enabled) palette[i % palette.size] else borderTint))
            at = maxOf(at,s.stop)
        }
        if (at < config.total) Box(Modifier.weight((config.total-at).toFloat()).fillMaxHeight().background(borderTint))
    }
}

private fun firstAvailable(config: StudioConfig): Int? {
    val used = BooleanArray(config.total.coerceAtLeast(0))
    config.segments.forEach { s ->
        for (i in s.start.coerceAtLeast(0) until s.stop.coerceAtMost(config.total)) used[i] = true
    }
    return used.indexOfFirst { !it }.takeIf { it >= 0 }
}

@Composable
private fun ScreenRegionPreview(segment: StudioSegment) {
    Canvas(Modifier.fillMaxWidth().height(145.dp).background(Color(0xFF0B1324), RoundedCornerShape(9.dp))
        .border(1.dp, borderTint, RoundedCornerShape(9.dp))) {
        val padding = 8.dp.toPx()
        val screen = Size(size.width - padding * 2, size.height - padding * 2)
        val anchor = Offset(padding, padding)
        drawRect(Color(0xFF1E3050), topLeft=anchor, size=screen)
        for (i in 1..3) {
            val x = padding + screen.width * i / 4
            drawLine(Color(0xFF3A4D69), Offset(x,padding), Offset(x,padding+screen.height),1.dp.toPx())
            val y = padding + screen.height * i / 4
            drawLine(Color(0xFF3A4D69), Offset(padding,y), Offset(padding+screen.width,y),1.dp.toPx())
        }
        val origin = Offset(padding + screen.width * segment.left / 100f,
            padding + screen.height * segment.top / 100f)
        val selectedSize = Size(screen.width*(segment.right-segment.left)/100f,
            screen.height*(segment.bottom-segment.top)/100f)
        drawRect(neon.copy(alpha=0.19f), topLeft=origin, size=selectedSize)
        drawRect(neon, topLeft=origin, size=selectedSize, style=Stroke(2.dp.toPx()))
    }
}

@Composable
private fun NumericField(title: String, value: String, onChange: (String)->Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(value = value, onValueChange = onChange, modifier=modifier,
        singleLine=true, label={ Text(title) },
        keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
}

@Composable
private fun NumberSetting(title: String, value: Int, range: IntRange, modifier: Modifier=Modifier,
                          onChange: (Int)->Unit) {
    var text by remember(title,value) { mutableStateOf(value.toString()) }
    NumericField(title,text,{ str ->
        text = str
        str.toIntOrNull()?.takeIf { it in range }?.let(onChange)
    },modifier)
}

@Composable
private fun HexColorSetting(title: String, color: Int, modifier: Modifier=Modifier, onChange:(Int)->Unit) {
    var text by remember(color,title) { mutableStateOf("%06X".format(color and 0xFFFFFF)) }
    OutlinedTextField(value=text, onValueChange={ str ->
        if (str.length <= 6 && str.all { it.isDigit() || it.uppercaseChar() in 'A'..'F' }) {
            text = str.uppercase()
            if (str.length == 6) str.toIntOrNull(16)?.let(onChange)
        }
    },label={ Text(title) },singleLine=true,modifier=modifier)
}

@Composable
private fun Choice(title: String, value: String, options: List<String>, modifier: Modifier,
                   onChange: (String)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick={expanded=true}, modifier=Modifier.fillMaxWidth()) {
            Text("$title: $value", maxLines=1,overflow=TextOverflow.Ellipsis)
        }
        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
            options.forEach { option ->
                DropdownMenuItem(text={ Text(option) },onClick={onChange(option);expanded=false})
            }
        }
    }
}
