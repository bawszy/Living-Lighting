package com.vasmarfas.UniversalAmbientLight.common.studio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Local, deterministic effects; they run inside the same outgoing WLED frame.
 * These do NOT claim to reproduce all effects shipped in any particular WLED firmware.
 * The original screen-capture pipeline and capture preferences are untouched.
 */
object StudioEffects {
    val modes = listOf(
        "screen", "off", "solid", "rainbow", "breathing", "gradient", "comet",
        "chase", "wipe", "sparkle", "twinkle", "fire", "candle", "meteor",
        "scanner", "theater", "pulse", "police", "aurora", "waves", "glitter",
        "lava", "sunrise", "ocean", "confetti", "colorloop", "dual_scanner",
        "lightning", "dots", "noise", "spectrum"
    )

    /** Null means sample the chosen rectangle of the captured screen instead. */
    fun pixel(mode: String, position: Int, count: Int, nowMs: Long,
              primary: Int, secondary: Int, speed: Int, intensity: Int): IntArray? {
        if (mode == "screen") return null
        val n = max(1, count)
        val pos = position.coerceIn(0, n - 1)
        val p = pos.toDouble() / n
        val velocity = speed.coerceIn(1, 100) / 50.0
        val time = nowMs * 0.001 * velocity
        val amount = intensity.coerceIn(0, 100) / 100.0
        val one = rgb(primary)
        val two = rgb(secondary)
        fun lerp(value: Double) = blend(one, two, value)
        fun brightness(value: Double) = scale(one, value)
        fun hue(value: Double) = hsv(value)
        fun flash(value: Double, color: IntArray = one) = scale(color, value.coerceIn(0.0, 1.0))
        fun pulse(value: Double) = 0.5 + 0.5 * sin(value)
        // Stable pseudo-random values; no per-frame Random objects and no global state.
        fun noise(cell: Long, seed: Long = 0): Double {
            var x = cell * 0x27d4eb2dL + seed * 0x165667b1L + pos.toLong() * 0x9e3779b9L
            x = (x xor (x ushr 16)) * 0x85ebca6bL
            x = (x xor (x ushr 13)) * 0xc2b2ae35L
            return ((x xor (x ushr 16)) ushr 33).toDouble() / (1L shl 31)
        }
        val phase = time * 2.0 * PI
        return when (mode) {
            "off" -> intArrayOf(0, 0, 0)
            "solid" -> one
            "rainbow", "spectrum" -> hue(p * (1.0 + amount * 3.0) + time * 0.1)
            "breathing" -> brightness(0.1 + 0.9 * pulse(phase))
            "gradient" -> lerp(p)
            "comet", "meteor" -> {
                val head = ((time * 15.0) % n + n) % n
                val distance = ((head - pos + n) % n)
                val trail = 2.0 + amount * 28.0
                flash((1.0 - distance / trail).coerceAtLeast(0.0))
            }
            "chase" -> if ((pos + (time * 9).toInt()) % max(2, (2 + amount * 16).toInt()) < 2) one else two
            "wipe" -> if (p <= (time * 0.3 % 1)) one else two
            "sparkle" -> {
                val frame = (time * 12).toLong()
                flash(if (noise(frame) > 0.94 - amount * 0.3) 1.0 else 0.04)
            }
            "twinkle" -> {
                val frame = (time * 4).toLong()
                val v = noise(frame)
                val t = (time * 4) % 1
                flash((0.06 + (if (v > 0.68 - amount * 0.2) v * sin(PI * t) else 0.0)))
            }
            "fire", "candle" -> {
                val tick = (time * (if (mode == "candle") 7 else 18)).toLong()
                val flicker = noise(tick, if (mode == "candle") 67 else 91)
                val warmth = if (mode == "candle") 0.2 + flicker * 0.18 else 0.15 + flicker * 0.55
                val base = intArrayOf(255, (100 + 90 * warmth).toInt(), (6 + 36 * warmth).toInt())
                flash(0.42 + 0.58 * flicker, base)
            }
            "scanner", "dual_scanner" -> {
                val x = abs((time * 0.42 % 2.0) - 1.0)
                val dist = abs(p - x)
                val radius = 0.015 + amount * 0.15
                val light = (1.0 - dist / radius).coerceAtLeast(0.0)
                if (mode == "dual_scanner") lerp(1.0 - light) else flash(light)
            }
            "theater" -> if (((pos + (time * 12).toInt()) % 6) < 3) one else intArrayOf(0,0,0)
            "pulse" -> lerp(pulse(phase + p * PI * (1 + amount * 6)))
            "police" -> if ((time * 6).toInt() % 2 == 0) {
                if (p < 0.5) intArrayOf(255,0,0) else intArrayOf(0,0,0)
            } else if (p >= 0.5) intArrayOf(0,60,255) else intArrayOf(0,0,0)
            "aurora" -> hue(0.37 + 0.18 * pulse(phase * 0.12 + p * 8.0)).let { flash(0.25 + 0.75 * pulse(phase * 0.4 + p * 12.0), it) }
            "waves" -> lerp(pulse(phase * 0.5 - p * 3.0 * PI))
            "glitter" -> {
                val tick = (time * 18).toLong()
                if (noise(tick) > 0.84 - amount * 0.25) intArrayOf(255,255,255) else one
            }
            "lava" -> {
                val v = pulse(phase * 0.25 + p * 15 + sin(phase * 0.13 + p * 5))
                blend(intArrayOf(90,0,0), intArrayOf(255,90,0), v)
            }
            "sunrise" -> blend(intArrayOf(100,0,30), intArrayOf(255,220,130), (p + (time * 0.03 % 1)).coerceIn(0.0,1.0))
            "ocean" -> blend(intArrayOf(0,8,70), intArrayOf(0,175,225), pulse(phase * 0.24 + p * 12.0))
            "confetti" -> {
                val tick = (time * 8).toLong()
                if (noise(tick) > 0.9 - amount * 0.35) hue(noise(tick, 123)) else flash(0.04)
            }
            "colorloop" -> hue(time * 0.035)
            "lightning" -> {
                val tick = (time * 11).toLong()
                val strike = if (noise(tick, 11) > 0.985 - amount * 0.045) 1.0 else 0.02
                flash(strike, intArrayOf(210,225,255))
            }
            "dots" -> if (pos % max(2, (20 - amount * 17).toInt()) == ((time * 7).toInt() % max(2, (20 - amount * 17).toInt()))) one else two
            "noise" -> lerp(noise((time * 10).toLong()))
            else -> null
        }
    }

    private fun rgb(c: Int) = intArrayOf((c shr 16) and 255, (c shr 8) and 255, c and 255)
    private fun blend(a: IntArray, b: IntArray, x: Double): IntArray {
        val v = x.coerceIn(0.0, 1.0)
        return intArrayOf((a[0] * (1 - v) + b[0] * v).toInt().coerceIn(0,255),
            (a[1] * (1-v) + b[1] * v).toInt().coerceIn(0,255),
            (a[2] * (1-v) + b[2] * v).toInt().coerceIn(0,255))
    }
    private fun scale(a: IntArray, amount: Double): IntArray = intArrayOf(
        (a[0] * amount).toInt().coerceIn(0,255),
        (a[1] * amount).toInt().coerceIn(0,255),
        (a[2] * amount).toInt().coerceIn(0,255))
    private fun hsv(value: Double): IntArray {
        val hue = ((value % 1.0) + 1.0) % 1.0
        val six = hue * 6.0
        val sector = six.toInt()
        val f = six - sector
        val v = (255 * f).toInt()
        val q = 255 - v
        return when (sector) {
            0 -> intArrayOf(255,v,0)
            1 -> intArrayOf(q,255,0)
            2 -> intArrayOf(0,255,v)
            3 -> intArrayOf(0,q,255)
            4 -> intArrayOf(v,0,255)
            else -> intArrayOf(255,0,q)
        }
    }
}

/** Lightweight capture diagnostic; does not change what can be captured. */
object StudioFrameMonitor {
    data class Sample(val frames: Long, val blackPercent: Int, val width: Int,
                      val height: Int, val lastAtMs: Long)
    @Volatile private var latest = Sample(0L, 0, 0, 0, 0L)
    fun snapshot(): Sample = latest
    fun inspect(data: ByteArray, width: Int, height: Int, now: Long): Sample {
        if (width < 1 || height < 1 || data.size.toLong() < width.toLong() * height * 3) return latest
        val pixels = width.toLong() * height
        val step = max(1L, pixels / 256L).toInt()
        var dark = 0
        var total = 0
        for (index in 0 until pixels.toInt() step step) {
            val offset = index * 3
            val r = data[offset].toInt() and 255
            val g = data[offset + 1].toInt() and 255
            val b = data[offset + 2].toInt() and 255
            if (max(r,max(g,b)) < 16) dark++
            total++
        }
        val next = Sample(latest.frames + 1, dark * 100 / max(1,total), width, height, now)
        latest = next
        return next
    }
}
