package com.vasmarfas.UniversalAmbientLight.common.remote

/**
 * Протокол управления телевизором с телефона.
 *
 * Поверх TCP идут кадры с длиной впереди ([FrameIO]); после рукопожатия ([Handshake]) каждый
 * кадр зашифрован ([SessionCipher]) и несёт JSON. Запрос телефона — `{"id", "op", ...}`,
 * ответ ТВ — `{"re": id, "ok", ...}`, событие ТВ без запроса — `{"ev", ...}`.
 *
 * [VERSION] меняется только при несовместимых изменениях: ТВ и телефон обновляются
 * независимо, и при расхождении телефон должен честно попросить обновить приложение.
 */
object RemoteProtocol {
    const val VERSION = 1

    const val SERVICE_TYPE = "_uamblight._tcp"
    const val DEFAULT_PORT = 38911

    const val URI_SCHEME = "uamblight"
    const val URI_HOST = "pair"

    const val OP_HELLO = "hello"
    const val OP_SNAPSHOT = "snapshot"
    const val OP_SET_PREFS = "set_prefs"
    const val OP_CAPTURE = "capture"
    const val OP_CLEAR = "clear"
    const val OP_LAYOUT_TEST = "layout_test"
    const val OP_DETECT_FRAME = "detect_frame"
    const val OP_ADB = "adb"
    const val OP_DEBUG_INFO = "debug_info"
    const val OP_PING = "ping"

    /**
     * Ввод на ТВ: кнопка, текст или мышь. Выполняется прямо в потоке чтения, без пула, -
     * порядок нажатий важнее всего. Запрос с id 0 ответа не получает: движения мыши идут
     * десятками в секунду, и ответы на них никому не нужны.
     */
    const val OP_INPUT = "input"
    const val OP_INPUT_PREPARE = "input_prepare"
    const val OP_APPS = "apps"
    const val OP_LAUNCH = "launch"

    /** Таймер сна: "minutes", 0 - отменить. */
    const val OP_SLEEP = "sleep"

    /** Автоподбор задержки: действие "a" - begin, dark (с "ms") или end. */
    const val OP_CALIBRATION = "calibration"

    const val INPUT_KEY = "key"
    const val INPUT_TEXT = "text"
    const val INPUT_POINTER = "pointer"

    const val EVENT_STATUS = "status"
    const val EVENT_PREFS = "prefs"

    const val CAPTURE_START = "start"
    const val CAPTURE_STOP = "stop"

    const val ADB_STATUS = "status"
    const val ADB_TEST = "test"
    const val ADB_LEGACY = "legacy"
    const val ADB_PAIR = "pair"
    const val ADB_AUTOPAIR = "autopair"
    const val ADB_GRANT = "grant"
    const val ADB_OPEN_DEV = "open_dev"
    const val ADB_OPEN_WIRELESS = "open_wireless"
    const val ADB_OPEN_ABOUT = "open_about"

    const val ERR_BAD_REQUEST = "bad_request"
    const val ERR_FAILED = "failed"

    /**
     * Что умеет приложение на ТВ сверх первой версии протокола. Новые команды добавляются
     * без смены [VERSION]: старый ТВ просто не объявит их, и телефон попросит его обновить.
     */
    const val FEATURE_EFFECTS = "effects"
    const val FEATURE_INPUT = "input"
    const val FEATURE_CALIBRATION = "calibration"
    const val FEATURE_SLEEP = "sleep"
    const val FEATURE_LAYOUT_TEST = "layout_test"
    const val FEATURE_EXTRA_OUTPUTS = "extra_outputs"

    /** Сколько телефонов держит ТВ одновременно; больше — признак ошибки, а не сценарий. */
    const val MAX_CLIENTS = 4

    const val PING_INTERVAL_MS = 15_000L

    /** ТВ рвёт соединение, если за это время не пришло ни одного кадра, даже пинга. */
    const val IDLE_TIMEOUT_MS = 60_000

    const val HANDSHAKE_TIMEOUT_MS = 10_000
}
