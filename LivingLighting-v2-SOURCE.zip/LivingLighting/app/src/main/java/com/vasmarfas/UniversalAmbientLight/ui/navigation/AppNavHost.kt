package com.vasmarfas.UniversalAmbientLight.ui.navigation

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.Icons
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.compose.composable
import androidx.navigation.compose.NavHost
import androidx.navigation.navArgument
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import com.vasmarfas.UniversalAmbientLight.common.remote.PairingPayload
import com.vasmarfas.UniversalAmbientLight.common.remote.RemoteProtocol
import com.vasmarfas.UniversalAmbientLight.common.remote.RemoteSession
import com.vasmarfas.UniversalAmbientLight.common.util.AnalyticsHelper
import com.vasmarfas.UniversalAmbientLight.common.util.DeviceProfile
import com.vasmarfas.UniversalAmbientLight.common.util.ExtraOutputs
import com.vasmarfas.UniversalAmbientLight.R
import com.vasmarfas.UniversalAmbientLight.ui.calibration.CalibrationScreen
import com.vasmarfas.UniversalAmbientLight.ui.camera.CameraSetupScreen
import com.vasmarfas.UniversalAmbientLight.ui.delay.DelayScreen
import com.vasmarfas.UniversalAmbientLight.ui.devices.DevicePickerScreen
import com.vasmarfas.UniversalAmbientLight.ui.devices.ExtraOutputScreen
import com.vasmarfas.UniversalAmbientLight.ui.devices.ExtraOutputsScreen
import com.vasmarfas.UniversalAmbientLight.ui.effects.EffectsScreen
import com.vasmarfas.UniversalAmbientLight.ui.home.describeSource
import com.vasmarfas.UniversalAmbientLight.ui.home.describeTargets
import com.vasmarfas.UniversalAmbientLight.ui.home.setupIssue
import com.vasmarfas.UniversalAmbientLight.ui.home.HelpDialog
import com.vasmarfas.UniversalAmbientLight.ui.home.HomeStatus
import com.vasmarfas.UniversalAmbientLight.ui.home.LowRatingDialog
import com.vasmarfas.UniversalAmbientLight.ui.home.MainScreen
import com.vasmarfas.UniversalAmbientLight.ui.home.openGitHubIssues
import com.vasmarfas.UniversalAmbientLight.ui.home.openGooglePlayReview
import com.vasmarfas.UniversalAmbientLight.ui.home.RatingDialog
import com.vasmarfas.UniversalAmbientLight.ui.home.RemoteEntry
import com.vasmarfas.UniversalAmbientLight.ui.home.SupportDialog
import com.vasmarfas.UniversalAmbientLight.ui.home.UrlDialog
import com.vasmarfas.UniversalAmbientLight.ui.led.LedLayoutScreen
import com.vasmarfas.UniversalAmbientLight.ui.remote.LocalRemote
import com.vasmarfas.UniversalAmbientLight.ui.remote.rememberSettingsPreferences
import com.vasmarfas.UniversalAmbientLight.ui.remote.RemoteBanner
import com.vasmarfas.UniversalAmbientLight.ui.remote.RemoteHostScreen
import com.vasmarfas.UniversalAmbientLight.ui.remote.RemoteTvsScreen
import com.vasmarfas.UniversalAmbientLight.ui.remote.TvRemoteScreen
import com.vasmarfas.UniversalAmbientLight.ui.settings.SettingsScreen
import com.vasmarfas.UniversalAmbientLight.ui.studio.StudioScreen

private val outputArgument = listOf(
    navArgument(Screen.ARG_OUTPUT) {
        type = NavType.IntType
        defaultValue = ExtraOutputs.MAIN
    }
)

@Composable
fun AppNavHost(
    navController: NavHostController,
    startDestination: String = Screen.Home.route,
    isRunning: Boolean,
    localPending: Boolean = false,
    onToggleClick: () -> Unit,
    lastError: String? = null,
    sleepAt: Long = 0L,
    onSleepTimer: (Int) -> Unit = {},
    remotePending: Boolean = false,
    pendingPayload: PairingPayload? = null,
    onPayloadConsumed: () -> Unit = {},
) {
    // QR открыли системной камерой: приложение запустилось по ссылке — сразу к сопряжению
    LaunchedEffect(pendingPayload) {
        if (pendingPayload != null) {
            navController.navigate(Screen.RemoteTvs.route) { launchSingleTop = true }
        }
    }

    NavHost(navController = navController, startDestination = startDestination) {
        composable(Screen.Home.route) {
            val context = LocalContext.current
            val remote = LocalRemote.current
            // rememberSaveable: поворот экрана не должен закрывать открытые диалоги
            var showHelpDialog by rememberSaveable { mutableStateOf(false) }
            var showSupportDialog by rememberSaveable { mutableStateOf(false) }
            var showUrlDialog by rememberSaveable { mutableStateOf<String?>(null) }
            var showRatingDialog by rememberSaveable { mutableStateOf(false) }
            var showLowRatingDialog by rememberSaveable { mutableStateOf(false) }

            val isTv = remember { DeviceProfile.isTv(context) }
            val prefs = rememberSettingsPreferences()

            // Источник захвата и цель перечитываются при возврате с экрана настроек. Именно по
            // ON_RESUME записи стека: currentBackStackEntry — не snapshot-state, и ключ по
            // нему срабатывал бы в произвольные моменты рекомпозиции.
            var captureSource by remember(prefs) {
                mutableStateOf(prefs.getString(R.string.pref_key_capture_source, "screen") ?: "screen")
            }
            var target by remember(prefs) { mutableStateOf(describeTargets(context, prefs)) }
            var source by remember(prefs) { mutableStateOf(describeSource(context, prefs)) }
            var setupHint by remember(prefs) { mutableStateOf(setupIssue(context, prefs)) }
            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner, prefs) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) {
                        captureSource =
                            prefs.getString(R.string.pref_key_capture_source, "screen") ?: "screen"
                        target = describeTargets(context, prefs)
                        source = describeSource(context, prefs)
                        setupHint = setupIssue(context, prefs)
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
            }

            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "home", "MainScreen")
            }

            val status = if (remote != null) {
                HomeStatus(
                    running = remote.running,
                    pending = remotePending || (remote.alive && !remote.running),
                    // Пока ждём запуска, прошлая ошибка ТВ только сбивала бы с толку
                    error = if (remotePending) null else lastError ?: remote.error,
                    target = target,
                    source = source,
                    sleepAt = remote.sleepAt
                )
            } else {
                HomeStatus(
                    running = isRunning,
                    pending = localPending,
                    error = lastError,
                    target = target,
                    source = source,
                    sleepAt = sleepAt
                )
            }
            val sleepSupported = remote == null ||
                    remote.caps?.features?.contains(RemoteProtocol.FEATURE_SLEEP) == true
            // На ТВ - пустить телефон, на телефоне - управлять телевизором, а уже подключённому
            // пульту - кнопки ТВ и выбор другого телевизора
            val remoteEntries = when {
                remote != null -> listOf(
                    RemoteEntry(stringResource(R.string.tv_remote_title), Icons.Default.Gamepad) {
                        navController.navigate(Screen.TvRemote.route) { launchSingleTop = true }
                    },
                    RemoteEntry(stringResource(R.string.remote_tvs_switch), Icons.Default.Tv) {
                        navController.navigate(Screen.RemoteTvs.route) { launchSingleTop = true }
                    }
                )

                isTv -> listOf(
                    RemoteEntry(stringResource(R.string.remote_host_title), Icons.Default.PhoneAndroid) {
                        navController.navigate(Screen.RemoteHost.route) { launchSingleTop = true }
                    }
                )

                else -> listOf(
                    RemoteEntry(stringResource(R.string.remote_tvs_title), Icons.Default.SettingsRemote) {
                        navController.navigate(Screen.RemoteTvs.route) { launchSingleTop = true }
                    }
                )
            }

            MainScreen(
                isRunning = if (remote != null) remote.running else isRunning,
                onToggleClick = onToggleClick,
                // singleTop: дребезг пульта на ТВ кладёт в стек два экрана настроек подряд
                onSettingsClick = {
                    navController.navigate(Screen.Settings.route) { launchSingleTop = true }
                },
                onEffectsClick = {
                    navController.navigate(Screen.Effects.route) { launchSingleTop = true }
                },
                captureSource = captureSource,
                status = status,
                localPreview = remote == null,
                remoteEntries = remoteEntries,
                onSleepTimer = if (sleepSupported) onSleepTimer else null,
                setupHint = setupHint,
                onSetupClick = {
                    navController.navigate(Screen.Devices.of()) { launchSingleTop = true }
                },
                topContent = {
                    if (remote != null) {
                        RemoteBanner(
                            snapshot = remote,
                            onDisconnect = { RemoteSession.deactivate() },
                            onRetry = { RemoteSession.reconnectNow() },
                            modifier = Modifier.padding(bottom = 24.dp)
                        )
                    }
                },
                onHelpClick = {
                    showHelpDialog = true
                    AnalyticsHelper.logHelpDialogOpened(context)
                },
                onSupportClick = {
                    showSupportDialog = true
                    AnalyticsHelper.logSupportDialogOpened(context)
                },
                onReportIssueClick = {
                    AnalyticsHelper.logSettingChanged(context, "report_issue_clicked", "true")
                    openGitHubIssues(context)
                },
                onLeaveReviewClick = {
                    AnalyticsHelper.logSettingChanged(context, "leave_review_clicked", "true")
                    showRatingDialog = true
                }
            )

            if (showHelpDialog) {
                HelpDialog(
                    onDismiss = { showHelpDialog = false },
                    onOpenChat = {
                        val url = context.getString(R.string.chat_url)
                        showHelpDialog = false

                        if (isTv) {
                            showUrlDialog = url
                        } else {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            } catch (e: Exception) {
                                showUrlDialog = url
                            }
                        }
                    },
                    onOpenGitHub = {
                        AnalyticsHelper.logHelpLinkOpened(context)
                        val url = context.getString(R.string.help_readme_url)
                        showHelpDialog = false

                        if (isTv) {
                            showUrlDialog = url
                        } else {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            try {
                                context.startActivity(intent)
                            } catch (e: ActivityNotFoundException) {
                                showUrlDialog = url
                            } catch (e: Exception) {
                                showUrlDialog = url
                            }
                        }
                    }
                )
            }

            if (showSupportDialog) {
                SupportDialog(
                    onDismiss = { showSupportDialog = false },
                    onOpenSupport = {
                        AnalyticsHelper.logSupportLinkOpened(context)
                        val url = context.getString(R.string.support_url)
                        showSupportDialog = false

                        if (isTv) {
                            showUrlDialog = url
                        } else {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            try {
                                context.startActivity(intent)
                            } catch (e: ActivityNotFoundException) {
                                showUrlDialog = url
                            } catch (e: Exception) {
                                showUrlDialog = url
                            }
                        }
                    }
                )
            }

            // Диалог оценки
            if (showRatingDialog) {
                RatingDialog(
                    onDismiss = { showRatingDialog = false },
                    onRatingSelected = { rating ->
                        showRatingDialog = false
                        AnalyticsHelper.logSettingChanged(
                            context,
                            "rating_selected",
                            rating.toString()
                        )
                        if (rating >= 4) {
                            openGooglePlayReview(context)
                        } else {
                            showLowRatingDialog = true
                        }
                    }
                )
            }

            if (showLowRatingDialog) {
                LowRatingDialog(
                    onDismiss = { showLowRatingDialog = false },
                    onReportIssue = {
                        showLowRatingDialog = false
                        AnalyticsHelper.logSettingChanged(
                            context,
                            "low_rating_report_issue",
                            "true"
                        )
                        openGitHubIssues(context)
                    }
                )
            }

            val urlToShow = showUrlDialog
            if (urlToShow != null && !showHelpDialog && !showSupportDialog && !showRatingDialog && !showLowRatingDialog) {
                UrlDialog(
                    url = urlToShow,
                    onDismiss = {
                        showUrlDialog = null
                    },
                    onOpenLink = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urlToShow))
                        try {
                            context.startActivity(intent)
                            showUrlDialog = null
                        } catch (e: Exception) {
                            // Если ссылку открыть не удалось, диалог оставляем открытым
                        }
                    }
                )
            }

        }
        composable(Screen.Settings.route) {
            val context = LocalContext.current
            // Состояние сбрасывается само с каждой новой записью стека; ключ по
            // currentBackStackEntry здесь ловил бы чужие переходы посреди анимации
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "settings", "SettingsScreen")
            }
            SettingsScreen(
                onBackClick = { navController.popBackStack() },
                onLedLayoutClick = {
                    navController.navigate(Screen.LedLayout.of()) { launchSingleTop = true }
                },
                onCameraSetupClick = {
                    navController.navigate(Screen.CameraSetup.route) { launchSingleTop = true }
                },
                onRemoteHostClick = {
                    navController.navigate(Screen.RemoteHost.route) { launchSingleTop = true }
                },
                onRemoteTvsClick = {
                    navController.navigate(Screen.RemoteTvs.route) { launchSingleTop = true }
                },
                onDelayClick = {
                    navController.navigate(Screen.Delay.route) { launchSingleTop = true }
                },
                onControllerClick = {
                    navController.navigate(Screen.Devices.of()) { launchSingleTop = true }
                },
                onExtraOutputsClick = {
                    navController.navigate(Screen.OutputList.route) { launchSingleTop = true }
                },
                onStudioClick = {
                    navController.navigate(Screen.Studio.route) { launchSingleTop = true }
                }
            )
        }
        composable(Screen.Studio.route) {
            StudioScreen(onBackClick = { navController.popBackStack() },
                onCaptureSettingsClick = { navController.navigate(Screen.Settings.route) })
        }
        composable(Screen.Devices.route, arguments = outputArgument) { entry ->
            val context = LocalContext.current
            val outputId = entry.arguments?.getInt(Screen.ARG_OUTPUT) ?: ExtraOutputs.MAIN
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "devices", "DevicePickerScreen")
            }
            DevicePickerScreen(
                onBackClick = { navController.popBackStack() },
                onLedLayoutClick = {
                    navController.navigate(Screen.LedLayout.of(outputId)) {
                        popUpTo(Screen.Devices.route) { inclusive = true }
                    }
                },
                outputId = outputId
            )
        }
        composable(Screen.LedLayout.route, arguments = outputArgument) { entry ->
            val context = LocalContext.current
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "led_layout", "LedLayoutScreen")
                AnalyticsHelper.logLedLayoutOpened(context)
            }
            LedLayoutScreen(
                onBackClick = { navController.popBackStack() },
                outputId = entry.arguments?.getInt(Screen.ARG_OUTPUT) ?: ExtraOutputs.MAIN
            )
        }
        composable(Screen.OutputList.route) {
            val context = LocalContext.current
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "extra_outputs", "ExtraOutputsScreen")
            }
            ExtraOutputsScreen(
                onBackClick = { navController.popBackStack() },
                onOutputClick = { id ->
                    navController.navigate(Screen.OutputDetails.of(id)) { launchSingleTop = true }
                },
                onOutputAdded = { id ->
                    // Новому контроллеру сначала нужен адрес; назад из выбора - на его настройки
                    navController.navigate(Screen.OutputDetails.of(id)) { launchSingleTop = true }
                    navController.navigate(Screen.Devices.of(id)) { launchSingleTop = true }
                }
            )
        }
        composable(Screen.OutputDetails.route, arguments = outputArgument) { entry ->
            val context = LocalContext.current
            val outputId = entry.arguments?.getInt(Screen.ARG_OUTPUT) ?: ExtraOutputs.MAIN
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "extra_output", "ExtraOutputScreen")
            }
            ExtraOutputScreen(
                outputId = outputId,
                onBackClick = { navController.popBackStack() },
                onControllerClick = {
                    navController.navigate(Screen.Devices.of(outputId)) { launchSingleTop = true }
                },
                onLedLayoutClick = {
                    navController.navigate(Screen.LedLayout.of(outputId)) { launchSingleTop = true }
                }
            )
        }
        composable(Screen.CameraSetup.route) {
            val context = LocalContext.current
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "camera_setup", "CameraSetupScreen")
            }
            CameraSetupScreen(
                onBackClick = { navController.popBackStack() }
            )
        }
        composable(Screen.RemoteHost.route) {
            val context = LocalContext.current
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "remote_host", "RemoteHostScreen")
            }
            RemoteHostScreen(onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Effects.route) {
            val context = LocalContext.current
            val remote = LocalRemote.current
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "effects", "EffectsScreen")
            }
            val running = remote?.running ?: isRunning
            EffectsScreen(
                running = running,
                onBackClick = { navController.popBackStack() },
                onStart = { if (!running) onToggleClick() },
                onStop = { if (running) onToggleClick() }
            )
        }
        composable(Screen.Delay.route) {
            val context = LocalContext.current
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "delay", "DelayScreen")
            }
            DelayScreen(
                onBackClick = { navController.popBackStack() },
                onCalibrateClick = {
                    navController.navigate(Screen.Calibration.route) { launchSingleTop = true }
                }
            )
        }
        composable(Screen.Calibration.route) {
            val context = LocalContext.current
            val remote = LocalRemote.current
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "calibration", "CalibrationScreen")
            }
            val running = remote?.running ?: isRunning
            CalibrationScreen(
                running = running,
                onBackClick = { navController.popBackStack() },
                onStartLighting = { if (!running) onToggleClick() }
            )
        }
        composable(Screen.TvRemote.route) {
            val context = LocalContext.current
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "tv_remote", "TvRemoteScreen")
            }
            TvRemoteScreen(onBackClick = { navController.popBackStack() })
        }
        composable(Screen.RemoteTvs.route) {
            val context = LocalContext.current
            LaunchedEffect(Unit) {
                AnalyticsHelper.logScreenView(context, "remote_tvs", "RemoteTvsScreen")
            }
            RemoteTvsScreen(
                onBackClick = { navController.popBackStack() },
                onControlTv = {
                    navController.popBackStack(Screen.Home.route, inclusive = false)
                },
                pendingPayload = pendingPayload,
                onPayloadConsumed = onPayloadConsumed
            )
        }
    }
}
