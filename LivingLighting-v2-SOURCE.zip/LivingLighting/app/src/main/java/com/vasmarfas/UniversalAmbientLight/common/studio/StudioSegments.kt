package com.vasmarfas.UniversalAmbientLight.common.studio

import android.content.SharedPreferences
import com.vasmarfas.UniversalAmbientLight.common.network.ColorRgb
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Physical addresses are zero-based and stop-exclusive, matching WLED. */
data class StudioSegment(
    val id: Int,
    val name: String,
    val start: Int,
    val stop: Int,
    val left: Int = 0,
    val top: Int = 0,
    val right: Int = 100,
    val bottom: Int = 100,
    val mapping: String = "horizontal",
    val mode: String = "screen",
    val color: Int = 0xFF6600,
    val brightness: Int = 100,
    val saturation: Int = 100,
    val smoothing: Int = 30,
    val reverse: Boolean = false,
    val enabled: Boolean = true,
    val secondaryColor: Int = 0x1269FF,
    val speed: Int = 50,
    val intensity: Int = 50,
) {
    val length: Int get() = stop - start

    fun valid(total: Int): Boolean = start >= 0 && stop > start && stop <= total &&
        left in 0..99 && top in 0..99 && right in 1..100 && bottom in 1..100 &&
        left < right && top < bottom && brightness in 0..100 &&
        saturation in 0..200 && smoothing in 0..95 &&
        speed in 1..100 && intensity in 0..100 &&
        mode in StudioEffects.modes && mapping in
        setOf("average", "horizontal", "vertical", "perimeter", "top", "right", "bottom", "left")
}

data class StudioConfig(val total: Int = 389, val segments: List<StudioSegment> = defaults()) {
    fun error(): String? {
        if (total !in 1..2048) return "Total LED count must be between 1 and 2048"
        if (segments.isEmpty()) return "Create at least one segment"
        if (segments.size > 64) return "Maximum 64 segments"
        if (segments.any { !it.valid(total) }) return "A segment has invalid LED or screen bounds"
        if (segments.map { it.id }.distinct().size != segments.size) return "Duplicate segment identifiers"
        val occupied = BooleanArray(total)
        for (segment in segments.filter { it.enabled }) {
            for (index in segment.start until segment.stop) {
                if (occupied[index]) return "Physical LED ranges overlap (screen regions may overlap)"
                occupied[index] = true
            }
        }
        return null
    }

    companion object {
        fun defaults() = listOf(
            StudioSegment(1, "Right, bottom and left shelves", 0, 240, mapping = "perimeter"),
            StudioSegment(2, "TV", 240, 354, mapping = "perimeter"),
            StudioSegment(3, "Lamp", 354, 389, mapping = "average")
        )
    }
}

/** Uses the source app's default SharedPreferences, never WLED hardware configuration. */
object StudioStore {
    const val ENABLED = "cj_studio_enabled_v1"
    private const val SEGMENTS = "cj_studio_segments_v1"
    private const val PRESETS = "cj_studio_presets_v1"
    const val TEST_ID = "cj_studio_test_id"
    // All compatibility experiments are opt-in, and are separate from the source app's capture preferences.
    private const val HOLD_BLACK = "cj_studio_hold_black_v2"
    private const val BLACK_LIMIT = "cj_studio_black_limit_v2"
    private const val DIAGNOSTICS = "cj_studio_diagnostics_v2"

    fun holdBlack(prefs: SharedPreferences) = prefs.getBoolean(HOLD_BLACK, false)
    fun setHoldBlack(prefs: SharedPreferences, value: Boolean) =
        prefs.edit().putBoolean(HOLD_BLACK, value).apply()
    fun blackLimit(prefs: SharedPreferences) = prefs.getInt(BLACK_LIMIT, 95).coerceIn(75, 100)
    fun setBlackLimit(prefs: SharedPreferences, value: Int) =
        prefs.edit().putInt(BLACK_LIMIT, value.coerceIn(75, 100)).apply()
    fun diagnostics(prefs: SharedPreferences) = prefs.getBoolean(DIAGNOSTICS, false)
    fun setDiagnostics(prefs: SharedPreferences, value: Boolean) =
        prefs.edit().putBoolean(DIAGNOSTICS, value).apply()

    fun enabled(prefs: SharedPreferences): Boolean = prefs.getBoolean(ENABLED, false)
    fun setEnabled(prefs: SharedPreferences, enabled: Boolean) =
        prefs.edit().putBoolean(ENABLED, enabled).apply()

    fun read(prefs: SharedPreferences): StudioConfig {
        return try {
            val json = prefs.getString(SEGMENTS, null) ?: return StudioConfig()
            decode(JSONObject(json)).takeIf { it.error() == null } ?: StudioConfig()
        } catch (_: Exception) { StudioConfig() }
    }

    fun save(prefs: SharedPreferences, config: StudioConfig): String? {
        config.error()?.let { return it }
        prefs.edit().putString(SEGMENTS, encode(config).toString()).apply()
        return null
    }

    fun test(prefs: SharedPreferences, id: Int) =
        prefs.edit().putInt(TEST_ID, id).apply()

    fun presets(prefs: SharedPreferences): List<String> = try {
        val obj = JSONObject(prefs.getString(PRESETS, "{}") ?: "{}")
        obj.keys().asSequence().toList().sorted()
    } catch (_: Exception) { emptyList() }

    fun savePreset(prefs: SharedPreferences, name: String, config: StudioConfig) {
        val clean = name.trim().take(48)
        if (clean.isBlank() || config.error() != null) return
        val obj = runCatching { JSONObject(prefs.getString(PRESETS, "{}") ?: "{}") }
            .getOrDefault(JSONObject())
        obj.put(clean, encode(config))
        prefs.edit().putString(PRESETS, obj.toString()).apply()
    }

    fun loadPreset(prefs: SharedPreferences, name: String): StudioConfig? = runCatching {
        val obj = JSONObject(prefs.getString(PRESETS, "{}") ?: "{}")
        decode(obj.getJSONObject(name)).takeIf { it.error() == null }
    }.getOrNull()

    fun deletePreset(prefs: SharedPreferences, name: String) {
        val obj = runCatching { JSONObject(prefs.getString(PRESETS, "{}") ?: "{}") }
            .getOrDefault(JSONObject())
        obj.remove(name)
        prefs.edit().putString(PRESETS, obj.toString()).apply()
    }

    private fun encode(config: StudioConfig) = JSONObject().put("total", config.total)
        .put("segments", JSONArray().apply {
            config.segments.forEach { s ->
                put(JSONObject().put("id", s.id).put("name", s.name)
                    .put("start", s.start).put("stop", s.stop)
                    .put("left", s.left).put("top", s.top).put("right", s.right)
                    .put("bottom", s.bottom).put("mapping", s.mapping)
                    .put("mode", s.mode).put("color", s.color)
                    .put("brightness", s.brightness).put("saturation", s.saturation)
                    .put("smoothing", s.smoothing).put("reverse", s.reverse)
                    .put("enabled", s.enabled).put("secondaryColor", s.secondaryColor)
                    .put("speed", s.speed).put("intensity", s.intensity))
            }
        })

    private fun decode(obj: JSONObject): StudioConfig {
        val array = obj.getJSONArray("segments")
        val segments = (0 until array.length()).map { i ->
            val s = array.getJSONObject(i)
            StudioSegment(
                id = s.getInt("id"), name = s.optString("name", "Zone ${i + 1}"),
                start = s.getInt("start"), stop = s.getInt("stop"),
                left = s.optInt("left", 0), top = s.optInt("top", 0),
                right = s.optInt("right", 100), bottom = s.optInt("bottom", 100),
                mapping = s.optString("mapping", "horizontal"),
                mode = s.optString("mode", "screen"), color = s.optInt("color", 0xFF6600),
                brightness = s.optInt("brightness", 100),
                saturation = s.optInt("saturation", 100),
                smoothing = s.optInt("smoothing", 30),
                reverse = s.optBoolean("reverse", false),
                enabled = s.optBoolean("enabled", true),
                secondaryColor = s.optInt("secondaryColor", 0x1269FF),
                speed = s.optInt("speed", 50),
                intensity = s.optInt("intensity", 50)
            )
        }
        return StudioConfig(obj.optInt("total", 389), segments)
    }
}

/** One capture -> one contiguous pixel frame. No additional network senders are created. */
class StudioMapper {
    private var last = emptyArray<ColorRgb>()

    fun render(config: StudioConfig, data: ByteArray, width: Int, height: Int,
               testId: Int = -1, nowMs: Long = System.currentTimeMillis(),
               holdBlackFrame: Boolean = false, blackThreshold: Int = 95): Array<ColorRgb> {
        if (config.error() != null || width <= 0 || height <= 0 ||
            data.size.toLong() < width.toLong() * height * 3) return emptyArray()
        val previous = last.takeIf { it.size == config.total }
        val capture = StudioFrameMonitor.inspect(data, width, height, nowMs)
        // Deliberately opt-in: holding on black may preserve stale colour during real dark scenes.
        if (holdBlackFrame && testId < 0 && previous != null &&
            capture.blackPercent >= blackThreshold.coerceIn(75, 100)) return previous
        val result = Array(config.total) { ColorRgb(0, 0, 0) }
        for (segment in config.segments.filter { it.enabled }) {
            val n = segment.length
            val left = (segment.left * width / 100).coerceIn(0, width - 1)
            val right = (segment.right * width / 100).coerceIn(left + 1, width)
            val top = (segment.top * height / 100).coerceIn(0, height - 1)
            val bottom = (segment.bottom * height / 100).coerceIn(top + 1, height)
            for (i in 0 until n) {
                val dst = segment.start + i
                val t = if (segment.reverse) n - 1 - i else i
                val rgb = when {
                    testId >= 0 -> if (testId == segment.id) intArrayOf(255, 255, 255)
                        else intArrayOf(0, 0, 0)
                    else -> StudioEffects.pixel(segment.mode, t, n, nowMs, segment.color,
                        segment.secondaryColor, segment.speed, segment.intensity)
                        ?: run {
                            val rect = sampleRect(segment.mapping, t, n, left, top, right, bottom)
                            sample(data, width, rect[0], rect[1], rect[2], rect[3])
                        }
                }
                val mean = (rgb[0] + rgb[1] + rgb[2]) / 3f
                val sat = segment.saturation / 100f
                val bri = segment.brightness / 100f
                val smooth = if (testId >= 0 || previous == null) 0f else segment.smoothing / 100f
                val old = previous?.get(dst)
                fun channel(raw: Int, oldValue: Int): Int {
                    val adjusted = ((mean + (raw - mean) * sat) * bri).toInt().coerceIn(0, 255)
                    return (adjusted * (1f - smooth) + oldValue * smooth).toInt().coerceIn(0, 255)
                }
                result[dst].set(channel(rgb[0], old?.red ?: 0),
                    channel(rgb[1], old?.green ?: 0), channel(rgb[2], old?.blue ?: 0))
            }
        }
        last = result
        return result
    }

    private fun sampleRect(mode: String, i: Int, n: Int, l: Int, t: Int, r: Int, b: Int): IntArray {
        val w = r - l; val h = b - t
        val depth = max(1, min(w, h) / 10)
        if (mode == "average") return intArrayOf(l, t, r, b)
        if (mode == "top") return intArrayOf(l + w * i / n, t, l + w * (i + 1) / n, t + depth)
        if (mode == "bottom") return intArrayOf(l + w * i / n, b - depth, l + w * (i + 1) / n, b)
        if (mode == "left") return intArrayOf(l, t + h * i / n, l + depth, t + h * (i + 1) / n)
        if (mode == "right") return intArrayOf(r - depth, t + h * i / n, r, t + h * (i + 1) / n)
        if (mode == "vertical") return intArrayOf(l, t + h * i / n, r, t + h * (i + 1) / n)
        if (mode == "perimeter") {
            val perimeter = 2L * (w + h)
            val position = perimeter * i / n
            val depth = max(1, min(w, h) / 10)
            return when {
                position < w -> intArrayOf(l + position.toInt(), t, l + position.toInt() + max(1, w / n), t + depth)
                position < w + h -> intArrayOf(r - depth, t + (position - w).toInt(), r, t + (position - w).toInt() + max(1, h / n))
                position < 2L * w + h -> intArrayOf(r - (position - w - h).toInt() - max(1, w / n), b - depth, r - (position - w - h).toInt(), b)
                else -> intArrayOf(l, b - (position - 2L * w - h).toInt() - max(1, h / n), l + depth, b - (position - 2L * w - h).toInt())
            }
        }
        return intArrayOf(l + w * i / n, t, l + w * (i + 1) / n, b)
    }

    private fun sample(data: ByteArray, width: Int, l: Int, t: Int, r: Int, b: Int): IntArray {
        val x0 = l.coerceIn(0, width - 1)
        val x1 = r.coerceIn(x0 + 1, width)
        val height = data.size / (width * 3)
        val y0 = t.coerceIn(0, height - 1)
        val y1 = b.coerceIn(y0 + 1, height)
        // Bound per-LED work so large screen regions and high frame rates stay responsive.
        val step = max(1, sqrt(((x1 - x0).toDouble() * (y1 - y0)) / 96.0).toInt())
        var rr = 0L; var gg = 0L; var bb = 0L; var count = 0
        for (y in y0 until y1 step step) for (x in x0 until x1 step step) {
            val idx = (y * width + x) * 3
            rr += data[idx].toInt() and 255
            gg += data[idx + 1].toInt() and 255
            bb += data[idx + 2].toInt() and 255
            count++
        }
        return intArrayOf((rr / count).toInt(), (gg / count).toInt(), (bb / count).toInt())
    }

}
