package com.vasmarfas.UniversalAmbientLight.common.studio

import android.content.SharedPreferences

/**
 * Reversible, explicit capture FPS/quality experiments.
 * The existing capture method, permissions, source, and defaults are never touched.
 * Settings are only changed after an explicit press of a trial button.
 */
object StudioCaptureTrials {
    private const val prefix = "cj_studio_trial_"
    private const val previousFps = "${prefix}previous_fps"
    private const val previousQuality = "${prefix}previous_quality"
    private const val hadFps = "${prefix}had_fps"
    private const val hadQuality = "${prefix}had_quality"
    private const val activeKey = "${prefix}active"

    // These are the existing Android resources' SharedPreferences keys in UAL v2.2.0.
    const val fpsKey = "pref_key_framerate"
    const val qualityKey = "pref_key_capture_quality"

    data class Trial(val label: String, val fps: String, val quality: String)
    val options = listOf(
        Trial("Low overhead", "15", "64"),
        Trial("Balanced", "30", "128"),
        Trial("More detail", "30", "256"),
        Trial("Fast response", "60", "128")
    )

    fun active(prefs: SharedPreferences): Boolean = prefs.getBoolean(activeKey, false)

    fun start(prefs: SharedPreferences, trial: Trial) {
        require(trial in options)
        val e = prefs.edit()
        if (!active(prefs)) {
            val presentFps = prefs.contains(fpsKey)
            val presentQuality = prefs.contains(qualityKey)
            e.putBoolean(hadFps, presentFps)
                .putBoolean(hadQuality, presentQuality)
                .putString(previousFps, prefs.getString(fpsKey, "") ?: "")
                .putString(previousQuality, prefs.getString(qualityKey, "") ?: "")
        }
        e.putBoolean(activeKey, true)
            .putString(fpsKey, trial.fps)
            .putString(qualityKey, trial.quality)
            .apply()
    }

    fun restore(prefs: SharedPreferences) {
        if (!active(prefs)) return
        val e = prefs.edit()
        if (prefs.getBoolean(hadFps, false))
            e.putString(fpsKey, prefs.getString(previousFps, "30"))
        else e.remove(fpsKey)
        if (prefs.getBoolean(hadQuality, false))
            e.putString(qualityKey, prefs.getString(previousQuality, "128"))
        else e.remove(qualityKey)
        e.remove(activeKey).remove(previousFps).remove(previousQuality)
            .remove(hadFps).remove(hadQuality).apply()
    }
}
