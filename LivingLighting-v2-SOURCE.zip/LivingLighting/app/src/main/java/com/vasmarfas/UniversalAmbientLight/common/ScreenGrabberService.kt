package com.vasmarfas.UniversalAmbientLight.common

import android.annotation.TargetApi
import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.annotation.RequiresApi
import androidx.annotation.StringRes
import androidx.core.app.ServiceCompat
import com.vasmarfas.UniversalAmbientLight.R
import com.vasmarfas.UniversalAmbientLight.common.effect.EffectConfig
import com.vasmarfas.UniversalAmbientLight.common.network.ConnectionConfig
import com.vasmarfas.UniversalAmbientLight.common.network.HomeAssistantLamp
import com.vasmarfas.UniversalAmbientLight.common.network.HyperionThread
import com.vasmarfas.UniversalAmbientLight.common.network.OutputFanOut
import com.vasmarfas.UniversalAmbientLight.common.network.OutputType
import com.vasmarfas.UniversalAmbientLight.common.util.AnalyticsHelper
import com.vasmarfas.UniversalAmbientLight.common.util.AppOptions
import com.vasmarfas.UniversalAmbientLight.common.util.DelayProfiles
import com.vasmarfas.UniversalAmbientLight.common.util.ExtraOutputs
import com.vasmarfas.UniversalAmbientLight.common.util.ForegroundApp
import com.vasmarfas.UniversalAmbientLight.common.util.LedLayout
import com.vasmarfas.UniversalAmbientLight.common.util.LocalNetworkAccess
import com.vasmarfas.UniversalAmbientLight.common.util.Preferences
import com.vasmarfas.UniversalAmbientLight.common.util.TclBypass
import java.util.Objects
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class ScreenGrabberService : Service() {

    private var mForegroundFailed = false
    private var mForegroundStarted = false
    private var mHandler: Handler? = null
    private var mStandby: StandbyController? = null

    private var mReconnectEnabled = false
    @Volatile private var mHasConnected = false
    @Volatile private var mEverConnected = false
    private var mMediaProjectionManager: MediaProjectionManager? = null
    private var mHyperionThread: HyperionThread? = null
    @Volatile private var mLayoutTestEnabled = false
    @Volatile private var mLayoutTestOutputOnly = false

    // Какой контроллер проверяется; у дополнительного свой поток и свой экран раскладки
    @Volatile private var mLayoutTestOutput = ExtraOutputs.MAIN

    // Контроллеры, работающие вместе с основным. Трогаем только с главного потока
    private val mExtraOutputs = LinkedHashMap<Int, ExtraOutput>()
    private var mFrameRate: Int = 0
    private var mCaptureQuality: Int = 0
    private var mHorizontalLEDCount: Int = 0
    private var mVerticalLEDCount: Int = 0
    private var mSendAverageColor: Boolean = false
    // Одновременно работает ровно один способ захвата: его выбирают startScreenRecord,
    // startAlternativeRecord и startCameraCapture по настройкам и доступности на прошивке.
    private var mActiveBackend: CaptureBackend? = null
    private var mCaptureSource: String = "screen" // "screen", "camera" или "effect"
    private var mNotificationManager: NotificationManager? = null
    private var mStartError: String? = null
    @Volatile private var mStartInProgress = false
    private var mConnectionType = "hyperion"
    private var mProjectionResultCode: Int? = null
    private var mProjectionDataExtras: android.os.Bundle? = null

    // Хранит AppOptions, отданные активному энкодеру: правки цветовых настроек по ходу
    // захвата подставляются сюда, не перезапуская сессию.
    @Volatile
    private var mActiveOptions: AppOptions? = null
    private var mPrefsListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? =
        null

    // Куда энкодер отдаёт кадры. Потоки вывода пересоздаются под тем же энкодером, когда
    // меняют адрес, протокол или сглаживание, — захват, а с ним и согласие MediaProjection,
    // при этом не трогается
    @Volatile
    private var mOutput: HyperionThread.HyperionThreadListener? = null
    private var mGate: OutputGate? = null

    // Правки настроек во время захвата копятся и применяются разом: пресет сглаживания или
    // ползунок пишут несколько ключей подряд
    private var mPendingOutputRestart = false
    private var mPendingCaptureRestart = false
    private var mPendingSessionRestart = false
    private var mPendingExtraSync = false
    private val mApplySettings = Runnable { applyPendingSettings() }

    // Задержка по приложениям: раз в несколько секунд смотрим, что на экране. Статистика
    // использования - вызов в системный сервис, с главного потока его уводим
    private var mAppWatch: ScheduledExecutorService? = null
    private var mForegroundPackage: String? = null

    // Автоподбор задержки с телефона: вывод без сглаживания и задержки, а на короткое время
    // лента гаснет, чтобы камера телефона увидела, сколько света даёт сам экран
    private var mCalibrating = false

    @Volatile
    private var mDarkUntil = 0L
    private var mDarkFrame: ByteArray? = null
    private val mEndCalibration = Runnable { setCalibrating(false) }

    // Таймер сна: подсветка выключается сама, как будто её выключили кнопкой
    private val mSleep = Runnable {
        Log.i(TAG, "Sleep timer elapsed, turning the lighting off")
        sSleepAt = 0L
        CaptureLauncher.stop(this)
    }

    private class ExtraOutput(val thread: HyperionThread, val config: ConnectionConfig)

    /** Проверка раскладки идёт на потоке основного вывода, а не дополнительного контроллера. */
    private val layoutTestOnPrimary: Boolean
        get() = mLayoutTestEnabled &&
                (mLayoutTestOutputOnly || mLayoutTestOutput == ExtraOutputs.MAIN)

    /**
     * Выход одного энкодера. После отцепления (перезапуск захвата с новыми настройками)
     * старый энкодер больше ничего не шлёт: его прощальные чёрные кадры и disconnect
     * погасили бы уже работающий новый вывод.
     */
    private inner class OutputGate : HyperionThread.HyperionThreadListener {
        @Volatile
        var attached = true

        override fun sendFrame(data: ByteArray, width: Int, height: Int) {
            if (!attached) return
            if (SystemClock.uptimeMillis() < mDarkUntil) {
                var dark = mDarkFrame
                if (dark == null || dark.size != data.size) {
                    dark = ByteArray(data.size)
                    mDarkFrame = dark
                }
                mOutput?.sendFrame(dark, width, height)
                return
            }
            mOutput?.sendFrame(data, width, height)
        }

        override fun clear() {
            if (attached) mOutput?.clear()
        }

        override fun disconnect() {
            if (attached) mOutput?.disconnect()
        }

        override fun sendStatus(isGrabbing: Boolean) {
            if (attached) mOutput?.sendStatus(isGrabbing)
        }
    }

    private val mReceiver = object : HyperionThreadBroadcaster {
        override fun onConnected() {
            if (DEBUG) Log.d(TAG, "Connected to Hyperion server")
            mHasConnected = true
            mEverConnected = true
            if (layoutTestOnPrimary) sLayoutTestConnected = true
            val prefs = Preferences(baseContext)
            val host = prefs.getString(R.string.pref_key_host, null)
            AnalyticsHelper.logConnectionSuccess(baseContext, mConnectionType, host)
            notifyActivity()
            // Сервис мог быть запущен при уже погашенном экране (например, переподключение USB в простое)
            maybeStandbyPauseOnConnect()
        }

        /** Гасим вывод, только если экран действительно погашен и keepalive выключен. */
        private fun maybeStandbyPauseOnConnect() {
            if (mCaptureSource == "camera" || effectStaysOn()) return
            if (Preferences(this@ScreenGrabberService).getBoolean(R.string.pref_key_standby_keepalive)) return
            val standby = mStandby ?: return
            if (!standby.isScreenOff()) return
            standby.schedulePause()
        }

        override fun onConnectionError(errorID: Int, error: String?) {
            if (layoutTestOnPrimary) sLayoutTestConnected = false
            Log.e(TAG, "Connection error: " + (error ?: "unknown"))
            AnalyticsHelper.logConnectionError(baseContext, mConnectionType, error)
            if (mEverConnected && mReconnectEnabled) {
                // Во время переподключения захват не останавливаем.
                mHasConnected = false
                mStartInProgress = true
                notifyActivity()
                Log.i(TAG, "Attempting automatic reconnect...")
            } else if (!mHasConnected) {
                mStartError = connectionErrorText(
                    R.string.error_adalight_unreachable,
                    R.string.error_lamps_unreachable,
                    R.string.error_device_unreachable,
                    R.string.error_server_unreachable
                )
                haltStartup()
            } else {
                mHasConnected = false
                mStartInProgress = false
                mStartError = connectionErrorText(
                    R.string.error_adalight_connection_lost,
                    R.string.error_lamps_connection_lost,
                    R.string.error_device_connection_lost,
                    R.string.error_connection_lost
                )
                stopSelf()
            }
        }

        /** Сервер, контроллер, лампы и Adalight на USB ломаются по-разному, и текст у каждого свой. */
        private fun connectionErrorText(
            @StringRes adalight: Int,
            @StringRes lamps: Int,
            @StringRes device: Int,
            @StringRes server: Int,
        ): String {
            val type = OutputType.of(mConnectionType)
            return resources.getString(
                when {
                    type == OutputType.ADALIGHT -> adalight
                    type == OutputType.HYPERION || type == OutputType.HOME_ASSISTANT -> server
                    type.isLamps -> lamps
                    else -> device
                }
            )
        }

        override fun onReceiveStatus(isCapturing: Boolean) {
            if (DEBUG) Log.v(TAG, "Received status: capturing=$isCapturing")
            notifyActivity()
        }
    }

    /**
     * Дополнительный контроллер — необязательная надстройка над основным выводом, поэтому
     * его сбои не должны валить сервис и основной канал: только лог, без mStartError и
     * haltStartup(). HyperionThread сам продолжит переподключаться на общих основаниях.
     */
    private inner class ExtraOutputReceiver(private val mId: Int) : HyperionThreadBroadcaster {
        override fun onConnected() {
            if (DEBUG) Log.d(TAG, "Connected to additional controller $mId")
            if (mLayoutTestEnabled && mLayoutTestOutput == mId) {
                sLayoutTestConnected = true
                notifyActivity()
            }
        }

        override fun onConnectionError(errorID: Int, error: String?) {
            Log.w(TAG, "Additional controller $mId error: " + (error ?: "unknown"))
        }

        override fun onReceiveStatus(isCapturing: Boolean) {}
    }

    private val mEventReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (Objects.requireNonNull(intent.action)) {
                Intent.ACTION_SCREEN_ON -> {
                    if (DEBUG) Log.v(TAG, "ACTION_SCREEN_ON intent received")
                    mStandby?.releaseWakeLock()
                    mStandby?.releaseWifiLock()

                    // Возобновляем вывод, если он был приглушён на время простоя
                    mStandby?.cancelPause()
                    forEachOutput {
                        it.resumeSending()
                        // Снимаем блокировку отправки WLED после ошибки EPERM, чтобы продолжить при пробуждении
                        it.resetBlockedIfWLED()
                    }

                    if (!isCapturing) {
                        val backend = mActiveBackend
                        if (backend != null) {
                            if (DEBUG) Log.v(TAG, "Resuming ${backend.javaClass.simpleName}")
                            backend.resumeRecording()
                            // После onStop от системы (сон ТВ) у ScreenEncoder уже нет ни
                            // ImageReader, ни потока захвата — resumeRecording() no-op, и
                            // единственный путь оживления — пересоздание из сохранённой
                            // проекции.
                            if (!isCapturing && backend is ScreenEncoder) {
                                restartEncoderFromSavedProjection()
                            }
                        } else if (mCaptureSource != "camera") {
                            // Если MediaProjection остановила система (уход в сон), resumeRecording() не спасёт —
                            // пересоздаём энкодер из сохранённых данных проекции.
                            if (DEBUG) Log.v(
                                TAG,
                                "No encoder active, trying restartEncoderFromSavedProjection"
                            )
                            restartEncoderFromSavedProjection()
                        }
                    }
                    notifyActivity()
                }

                Intent.ACTION_SCREEN_OFF -> {
                    if (DEBUG) Log.v(TAG, "ACTION_SCREEN_OFF intent received")
                    // Камера снимает внешний телевизор, сон экрана устройства ей безразличен — работаем как работали.
                    // Так же живёт эффект, который попросили не гасить: ТВ выключен, лента светит ночником
                    val isCamera = mCaptureSource == "camera" || effectStaysOn()
                    val standbyKeepalive =
                        Preferences(context).getBoolean(R.string.pref_key_standby_keepalive)
                    if (standbyKeepalive || isCamera) {
                        // На части телевизоров процессор уходит в глубокий сон, keepalive-потоки перестают слать
                        // пакеты, и через ~10 секунд WLED возвращается к своему эффекту. PARTIAL_WAKE_LOCK этому мешает.
                        mStandby?.acquireWakeLock()
                        mStandby?.acquireWifiLock()
                    }
                    // Камера снимает внешний телевизор, её кадры не зависят от экрана
                    // устройства — гасим ленту только для экранных способов захвата.
                    // Эффект рисует кадры сам и зажёг бы ленту снова - его останавливаем
                    when (val backend = mActiveBackend) {
                        is CameraEncoder -> {}
                        is EffectEncoder -> if (!isCamera) backend.pause()
                        else -> backend?.clearLights()
                    }
                    if (!standbyKeepalive && !isCamera) {
                        // Keepalive в простое выключен: даём чёрным кадрам уйти и молчим до SCREEN_ON
                        mStandby?.schedulePause()
                    }
                }

                Intent.ACTION_CONFIGURATION_CHANGED -> {
                    if (DEBUG) Log.v(TAG, "ACTION_CONFIGURATION_CHANGED intent received")
                    mActiveBackend?.setOrientation(resources.configuration.orientation)
                }

                Intent.ACTION_SHUTDOWN, Intent.ACTION_REBOOT -> {
                    if (DEBUG) Log.v(TAG, "ACTION_SHUTDOWN|ACTION_REBOOT intent received")
                    stopAllCapture()
                }
            }
        }
    }

    override fun onCreate() {
        sInstanceRunning = true
        mNotificationManager = getSystemService(NOTIFICATION_SERVICE) as? NotificationManager
        val handler = Handler(Looper.getMainLooper())
        mHandler = handler
        mStandby = StandbyController(this, handler) {
            if (DEBUG) Log.v(TAG, "Standby: pausing all LED output")
            forEachOutput { it.pauseSending() }
        }

        // На запуске пробуем shell-обход для устройств TCL
        if (TclBypass.isTclDevice() || TclBypass.isRestrictedManufacturer()) {
            Log.i(TAG, "Detected restricted manufacturer, attempting shell bypass")
            TclBypass.tryShellBypass(this)
        }

        AutoStart.scheduleWatchdog(this)

        super.onCreate()
    }

    private fun prepared(outputOnly: Boolean = false): Boolean {
        AnalyticsHelper.syncCrashlyticsContext(baseContext)
        val shared = Preferences(baseContext)
        // Адресная проверка без захвата открывает только проверяемый контроллер, и на это
        // время он занимает место основного вывода
        val prefs = if (outputOnly) shared.forOutput(mLayoutTestOutput) else shared
        mConnectionType =
            prefs.getString(R.string.pref_key_connection_type, "hyperion") ?: "hyperion"

        // Для адресного теста видеозахват не нужен, но выбранный контроллер,
        // локальная сеть и раскладка должны быть настроены так же, как при обычном выводе.
        validateOutput(baseContext, prefs)?.let { error ->
            mStartError = error.message
            AnalyticsHelper.logServiceError(baseContext, error.code, error.details)
            return false
        }

        mFrameRate = shared.getInt(R.string.pref_key_framerate)

        try {
            val captureQualityStr = shared.getString(R.string.pref_key_capture_quality, "128")
                ?.takeIf { it.isNotBlank() } ?: "128"
            mCaptureQuality = Integer.parseInt(captureQualityStr)
        } catch (e: NumberFormatException) {
            mCaptureQuality = 128
        }

        mHorizontalLEDCount = shared.getInt(R.string.pref_key_x_led)
        mVerticalLEDCount = shared.getInt(R.string.pref_key_y_led)
        mSendAverageColor = shared.getBoolean(R.string.pref_key_use_avg_color)

        mMediaProjectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        val method = shared.getString(R.string.pref_key_capture_method, "media_projection")
        if (!outputOnly && mMediaProjectionManager == null && method == "media_projection") {
            mStartError = resources.getString(R.string.error_media_projection_denied)
            AnalyticsHelper.logServiceError(baseContext, "media_projection_manager_null", null)
            return false
        }

        val config = ConnectionConfig.from(prefs, effectiveOutputDelay(shared))
        mReconnectEnabled = config.reconnect
        val thread = HyperionThread(mReceiver, baseContext, config, prefs)
        if (layoutTestOnPrimary) thread.setLayoutTestEnabled(true)
        if (mCalibrating) thread.setCalibrating(true)
        mHyperionThread = thread
        thread.start()

        publishOutput()
        // Дополнительные контроллеры не участвуют в проверке основного: при самостоятельном
        // тесте не открываем лишних подключений без видеозахвата.
        if (!outputOnly) syncExtraOutputs()
        if (mCaptureSource == "screen") startAppWatch()

        mStartError = null
        return true
    }

    private inline fun forEachOutput(action: (HyperionThread) -> Unit) {
        mHyperionThread?.let(action)
        mExtraOutputs.values.forEach { action(it.thread) }
    }

    private fun publishOutput() {
        mOutput = mHyperionThread?.let { primary ->
            OutputFanOut(primary.receiver, mExtraOutputs.values.map { it.thread.receiver })
        }
    }

    /** Какие контроллеры должны работать сейчас; выключенный поднимается только для проверки. */
    private fun wantedExtraOutputs(): Map<Int, ConnectionConfig> {
        val shared = Preferences(baseContext)
        val delay = effectiveOutputDelay(shared)
        val wanted = LinkedHashMap<Int, ConnectionConfig>()
        for (id in ExtraOutputs.ids(shared)) {
            val prefs = shared.forOutput(id)
            val testing = mLayoutTestEnabled && mLayoutTestOutput == id
            if (!testing && !prefs.getBoolean(R.string.pref_key_output_enabled)) continue
            val error = validateOutput(baseContext, prefs)
            if (error != null) {
                Log.w(TAG, "Additional controller $id is not configured: ${error.code}")
                continue
            }
            wanted[id] = ConnectionConfig.from(prefs, delay)
        }
        return wanted
    }

    /**
     * Приводит работающие контроллеры к настройкам. Поток пересоздаётся, только если изменился
     * его конфиг: раскладку клиент перечитывает сам, а перезапуск на каждую её правку гасил бы
     * ленту. Основной вывод при этом не трогаем.
     */
    private fun syncExtraOutputs() {
        val wanted = wantedExtraOutputs()
        val stale = mExtraOutputs.filter { (id, output) ->
            // Задержку меняют на ходу, поток из-за неё пересоздавать незачем
            wanted[id]?.copy(outputDelayMs = output.config.outputDelayMs) != output.config
        }
        if (stale.isEmpty()) {
            startExtraOutputs()
            return
        }
        mExtraOutputs -= stale.keys
        publishOutput()
        stale.values.forEach { it.thread.interrupt() }
        Thread({
            // Новое подключение только после закрытия старого: сессия у моста Hue одна
            stale.values.forEach { closeOutput(it.thread) }
            mHandler?.post { startExtraOutputs() }
        }, "extra-output-restart").apply { isDaemon = true }.start()
    }

    private fun startExtraOutputs() {
        if (mHyperionThread == null || mLayoutTestOutputOnly) return
        val missing = wantedExtraOutputs().filterKeys { it !in mExtraOutputs }
        if (missing.isEmpty()) return
        val shared = Preferences(baseContext)
        for ((id, config) in missing) {
            val thread = HyperionThread(ExtraOutputReceiver(id), baseContext, config, shared.forOutput(id))
            if (mLayoutTestEnabled && mLayoutTestOutput == id) thread.setLayoutTestEnabled(true)
            if (mCalibrating) thread.setCalibrating(true)
            mExtraOutputs[id] = ExtraOutput(thread, config)
            thread.start()
        }
        publishOutput()
    }

    private fun closeOutput(thread: HyperionThread) {
        try {
            thread.receiver.disconnect()
        } catch (e: Exception) {
            // Закрытие идёт разом для всех контроллеров: сбой одного клиента не должен
            // оставить остальные гореть
            Log.w(TAG, "Output shutdown failed: ${e.message}")
        }
    }

    private fun layoutTestThread(): HyperionThread? =
        if (mLayoutTestOutputOnly || mLayoutTestOutput == ExtraOutputs.MAIN) {
            mHyperionThread
        } else {
            mExtraOutputs[mLayoutTestOutput]?.thread
        }

    private fun setSleepTimer(minutes: Int) {
        val handler = mHandler ?: return
        handler.removeCallbacks(mSleep)
        if (minutes > 0 && mHyperionThread != null) {
            val delayMs = minutes * 60_000L
            sSleepAt = System.currentTimeMillis() + delayMs
            handler.postDelayed(mSleep, delayMs)
        } else {
            sSleepAt = 0L
        }
        notifyActivity()
    }

    private fun effectiveOutputDelay(prefs: Preferences): Long =
        DelayProfiles.effectiveDelay(prefs, mForegroundPackage).toLong()

    /**
     * Замер задержки: сглаживание и задержка вывода снимаются на ходу, без переподключения.
     * Если телефон пропал посреди замера, режим снимется сам через [MAX_CALIBRATION_MS].
     */
    private fun setCalibrating(calibrating: Boolean) {
        mHandler?.removeCallbacks(mEndCalibration)
        mCalibrating = calibrating
        if (!calibrating) mDarkUntil = 0L
        forEachOutput { it.setCalibrating(calibrating) }
        if (calibrating) mHandler?.postDelayed(mEndCalibration, MAX_CALIBRATION_MS)
        Log.i(TAG, if (calibrating) "Delay calibration started" else "Delay calibration finished")
    }

    private fun applyOutputDelay() {
        val delay = effectiveOutputDelay(Preferences(this))
        forEachOutput { it.setOutputDelay(delay) }
    }

    /** Следить за приложением на экране есть смысл, только когда заданы задержки по приложениям. */
    private fun startAppWatch() {
        if (mAppWatch != null) return
        val profiles = Preferences(this).getString(R.string.pref_key_delay_profiles, "")
        if (DelayProfiles.parse(profiles).isEmpty()) return
        val foreground = ForegroundApp(this)
        mAppWatch = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "app-watch") }.also {
            it.scheduleWithFixedDelay({
                val pkg = foreground.current()
                mHandler?.post { onForegroundApp(pkg) }
            }, 0, APP_WATCH_INTERVAL_MS, TimeUnit.MILLISECONDS)
        }
    }

    private fun stopAppWatch() {
        mAppWatch?.shutdownNow()
        mAppWatch = null
        mForegroundPackage = null
    }

    private fun onForegroundApp(pkg: String?) {
        if (mAppWatch == null || pkg == mForegroundPackage) return
        mForegroundPackage = pkg
        applyOutputDelay()
    }

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (DEBUG) Log.v(TAG, "Start command received")

        // startForeground обязан быть вызван в пределах ~5 секунд после каждого
        // startForegroundService, иначе Android бросит ForegroundServiceDidNotStartInTime.
        ensureForegroundStarted(initialForegroundTypeFor(intent?.action))

        super.onStartCommand(intent, flags, startId)
        if (intent == null || intent.action == null) {
            val nullItem = if (intent == null) "intent" else "action"
            if (DEBUG) Log.v(TAG, "Null $nullItem provided to start command")
            // START_STICKY: система подняла сервис заново после гибели процесса (частая история
            // у ТВ, выгружающих приложения на время сна). Подсветка работала — возвращаем её
            if (intent == null && mHyperionThread == null && AutoStart.shouldResume(this)) {
                val prefs = Preferences(this)
                val source = prefs.getString(R.string.pref_key_capture_source, "screen")
                val method = prefs.getString(R.string.pref_key_capture_method, "media_projection")
                val adalight = "adalight".equals(
                    prefs.getString(R.string.pref_key_connection_type, "hyperion"),
                    ignoreCase = true
                )
                if (source == "screen" && method != "media_projection" && !adalight) {
                    Log.i(TAG, "Restarted by the system after the process died, resuming capture")
                    return onStartCommand(Intent(this, javaClass).setAction(ACTION_START), flags, startId)
                }
                if (source == "effect" && !adalight) {
                    Log.i(TAG, "Restarted by the system after the process died, resuming the effect")
                    return onStartCommand(Intent(this, javaClass).setAction(ACTION_START_EFFECT), flags, startId)
                }
                // Остальным путям нужен диалог (согласие на запись экрана, разрешения на USB и
                // камеру) — их поднимает CaptureLauncher, когда этот экземпляр уже остановлен
                val app = applicationContext
                mHandler?.postDelayed({ AutoStart.resume(app) }, SESSION_RESTART_DELAY_MS)
            }
            stopSelf()
            return START_NOT_STICKY
        } else {
            val action = intent.action
            if (DEBUG) Log.v(TAG, "Start command action: " + action.toString())
            when (action) {
                ACTION_START -> if (mHyperionThread == null) {
                    mStartInProgress = true
                    mHasConnected = false
                    mEverConnected = false
                    notifyActivity()
                    mCaptureSource = "screen"
                    val prefs = Preferences(this)
                    val method =
                        prefs.getString(R.string.pref_key_capture_method, "media_projection")
                            ?: "media_projection"

                    val useMediaProjection = method == "media_projection"
                    val foregroundType = if (useMediaProjection)
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    else
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK

                    if (!tryStartForegroundCompat(foregroundType)) return stopWithoutForeground()

                    val isPrepared = prepared()
                    if (isPrepared) {
                        if (useMediaProjection) {
                            try {
                                startScreenRecord(intent)
                            } catch (e: SecurityException) {
                                Log.e(TAG, "Failed to start screen recording: " + e.message)
                                mStartError =
                                    resources.getString(R.string.error_media_projection_denied)
                                AnalyticsHelper.logServiceError(
                                    baseContext,
                                    "security_exception",
                                    e.message
                                )
                                haltStartup()
                                return START_STICKY
                            }
                        } else {
                            startAlternativeRecord(method)
                        }

                        registerEventReceiver()
                    } else {
                        haltStartup()
                    }
                }

                ACTION_START_CAMERA -> if (mHyperionThread == null) {
                    mStartInProgress = true
                    mHasConnected = false
                    mEverConnected = false
                    notifyActivity()
                    mCaptureSource = "camera"
                    if (!tryStartForegroundCamera()) return stopWithoutForeground()

                    val isPrepared = prepared()
                    if (isPrepared) {
                        startCameraCapture()
                        registerEventReceiver()
                    } else {
                        haltStartup()
                    }
                }

                ACTION_START_EFFECT -> if (mHyperionThread == null) {
                    mStartInProgress = true
                    mHasConnected = false
                    mEverConnected = false
                    notifyActivity()
                    mCaptureSource = "effect"
                    if (!tryStartForegroundCompat(ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)) {
                        return stopWithoutForeground()
                    }

                    if (prepared()) {
                        startEffect()
                        registerEventReceiver()
                    } else {
                        haltStartup()
                    }
                }

                ACTION_SLEEP_TIMER -> {
                    setSleepTimer(intent.getIntExtra(EXTRA_SLEEP_MINUTES, 0))
                    if (mHyperionThread == null) stopSelf()
                }

                ACTION_CALIBRATION -> {
                    when (intent.getStringExtra(EXTRA_CALIBRATION)) {
                        CALIBRATION_BEGIN -> setCalibrating(true)
                        CALIBRATION_END -> setCalibrating(false)
                        CALIBRATION_DARK -> mDarkUntil =
                            SystemClock.uptimeMillis() + intent.getLongExtra(EXTRA_DARK_MS, 0L).coerceIn(0L, MAX_DARK_MS)
                    }
                    if (mHyperionThread == null) stopSelf()
                }

                ACTION_DETECT_FRAME -> {
                    // Кнопка автоподстройки: перезапускаем поиск экрана прямо в идущей
                    // сессии камеры.
                    val backend = mActiveBackend
                    if (backend is CameraEncoder) {
                        backend.requestFrameDetection()
                    } else {
                        Log.i(TAG, "ACTION_DETECT_FRAME ignored: camera capture is not running")
                        // Интент мог создать сервис заново (кнопку нажали в момент его
                        // остановки) — не оставляем пустой foreground-сервис висеть.
                        if (mHyperionThread == null) stopSelf()
                    }
                }

                ACTION_STOP -> {
                    stopAllCapture()
                    notifyActivity()
                }
                ACTION_LAYOUT_TEST -> {
                    val enabled = intent.getBooleanExtra(EXTRA_LAYOUT_TEST_ENABLED, false)
                    if (enabled) {
                        mLayoutTestOutput = intent.getIntExtra(EXTRA_OUTPUT_ID, ExtraOutputs.MAIN)
                        if (mHyperionThread == null) {
                            // При выключенном захвате открываем только адресный вывод.
                            // Ни MediaProjection, ни VSS, ни новый энкодер не запускаются.
                            val outputType = Preferences(this).forOutput(mLayoutTestOutput).getString(
                                R.string.pref_key_connection_type, "hyperion"
                            )
                            if (!OutputType.of(outputType).supportsLedLayoutTest) {
                                Log.w(TAG, "LED layout test requires an addressable output")
                                stopSelf()
                            } else {
                                mLayoutTestEnabled = true
                                sLayoutTestConnected = false
                                mLayoutTestOutputOnly = true
                                mCaptureSource = "layout_test"
                                if (!prepared(outputOnly = true)) {
                                    mLayoutTestEnabled = false
                                    mLayoutTestOutputOnly = false
                                    haltStartup()
                                }
                            }
                        } else {
                            mLayoutTestEnabled = true
                            val thread = layoutTestThread()
                            sLayoutTestConnected = thread?.isOutputConnected() == true
                            // Потока нет у выключенного контроллера: поднимается на время проверки
                            if (thread != null) thread.setLayoutTestEnabled(true) else syncExtraOutputs()
                            notifyActivity()
                        }
                    } else {
                        mLayoutTestEnabled = false
                        sLayoutTestConnected = false
                        layoutTestThread()?.setLayoutTestEnabled(false)
                        val testedExtra = !mLayoutTestOutputOnly && mLayoutTestOutput != ExtraOutputs.MAIN
                        mLayoutTestOutput = ExtraOutputs.MAIN
                        if (mLayoutTestOutputOnly) {
                            // Тест был единственной причиной работы сервиса:
                            // гасим ленту и освобождаем соединение при закрытии страницы.
                            mLayoutTestOutputOnly = false
                            stopAllCapture()
                            stopSelf()
                        } else if (mHyperionThread == null) {
                            stopSelf()
                        } else if (testedExtra) {
                            syncExtraOutputs()
                        }
                    }
                }
                ACTION_CLEAR -> {
                    // Один чёрный кадр, но соединение оставляем
                    val backend = mActiveBackend
                    if (backend != null) {
                        if (DEBUG) Log.v(
                            TAG,
                            "ACTION_CLEAR: clearing lights once (${backend.javaClass.simpleName})"
                        )
                        backend.clearLights()
                    } else if (mHyperionThread == null) {
                        // Интент пришёл в незапущенный сервис и создал его — не оставляем
                        // пустой foreground-сервис висеть с уведомлением
                        stopSelf()
                    }
                }

                GET_STATUS -> {
                    notifyActivity()
                    // Запрос статуса мог создать сервис заново (гонка с onDestroy) — не
                    // оставляем пустой foreground-сервис висеть с уведомлением
                    if (mHyperionThread == null) stopSelf()
                }

                ACTION_EXIT -> {
                    // «Выход» из уведомления, плитки и ярлыка — решение пользователя: автозапуск
                    // и сторож больше не должны поднимать подсветку
                    Preferences(this).putBoolean(R.string.pref_key_lighting_was_active, false)
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onDestroy() {
        if (DEBUG) Log.v(TAG, "Ending service")

        try {
            unregisterReceiver(mEventReceiver)
        } catch (e: Exception) {
            if (DEBUG) Log.v(TAG, "Wake receiver not registered")
        }

        unregisterColorPrefsListener()
        mHandler?.removeCallbacks(mApplySettings)
        mHandler?.removeCallbacks(mEndCalibration)
        mHandler?.removeCallbacks(mSleep)
        sSleepAt = 0L
        stopAppWatch()
        mActiveOptions = null

        mStandby?.releaseAll()
        stopAllCapture()
        stopForeground(true)
        mForegroundStarted = false
        notifyActivity()
        sInstanceRunning = false

        super.onDestroy()
    }

    private fun registerEventReceiver() {
        val intentFilter = IntentFilter()
        intentFilter.addAction(Intent.ACTION_SCREEN_ON)
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF)
        intentFilter.addAction(Intent.ACTION_CONFIGURATION_CHANGED)
        intentFilter.addAction(Intent.ACTION_REBOOT)
        intentFilter.addAction(Intent.ACTION_SHUTDOWN)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(mEventReceiver, intentFilter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(mEventReceiver, intentFilter)
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun initialForegroundTypeFor(action: String?): Int = when (action) {
        ACTION_START_CAMERA -> ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        ACTION_START -> {
            // Тип mediaProjection без выданного согласия роняет startForeground на 14+
            // (исключение глотается, но сервис остаётся не-foreground до повторной
            // попытки) — для методов без проекции сразу берём mediaPlayback
            val method = Preferences(this)
                .getString(R.string.pref_key_capture_method, "media_projection")
            if (method == "media_projection") {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            }
        }

        else -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
    }

    /** Идемпотентный startForeground — вызывать можно сколько угодно раз. */
    private fun ensureForegroundStarted(type: Int) {
        if (mForegroundStarted) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            mForegroundStarted = true
        } catch (e: Exception) {
            Log.w(TAG, "ensureForegroundStarted failed (type=$type): ${e.message}")
        }
    }

    private fun tryStartForegroundCompat(type: Int): Boolean {
        if (mForegroundStarted) {
            mForegroundFailed = false
            return true
        }
        mForegroundFailed = false

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this, NOTIFICATION_ID, notification,
                    type
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            mForegroundStarted = true
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Foreground start failed: " + e.message)
            mForegroundFailed = true
        }

        if (mForegroundFailed) {
            try {
                Thread.sleep(100)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ServiceCompat.startForeground(
                        this, NOTIFICATION_ID, notification,
                        type
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
                mForegroundFailed = false
                mForegroundStarted = true
                return true
            } catch (e: Exception) {
                Log.e(TAG, "Foreground retry failed: " + e.message)
            }
        }

        notifyTclBlocked()
        return false
    }

    private fun tryStartForegroundCamera(): Boolean {
        if (mForegroundStarted) {
            mForegroundFailed = false
            return true
        }
        mForegroundFailed = false

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this, NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            mForegroundStarted = true
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Foreground start (camera) failed: " + e.message)
            mForegroundFailed = true
        }

        // Повторная попытка
        if (mForegroundFailed) {
            try {
                Thread.sleep(100)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ServiceCompat.startForeground(
                        this, NOTIFICATION_ID, notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
                mForegroundFailed = false
                mForegroundStarted = true
                return true
            } catch (e: Exception) {
                Log.e(TAG, "Foreground retry (camera) failed: " + e.message)
            }
        }

        notifyTclBlocked()
        return false
    }

    /** Выход нового энкодера; прежний энкодер при этом отцепляется. */
    private fun newGate(): HyperionThread.HyperionThreadListener {
        mGate?.attached = false
        return OutputGate().also { mGate = it }
    }

    private fun startCameraCapture() {
        if (DEBUG) Log.v(TAG, "Starting camera capture")
        val thread = mHyperionThread
        if (thread == null) {
            Log.e(TAG, "HyperionThread is null; cannot start camera capture")
            mStartError = resources.getString(R.string.error_server_unreachable)
            haltStartup()
            return
        }

        val prefs = Preferences(this)
        val options = buildAppOptions(prefs)

        val cornersStr = prefs.getString(R.string.pref_key_camera_corners, null)
        val corners = CameraEncoder.parseCornersString(cornersStr)

        val encoder = CameraEncoder(
            this,
            newGate(),
            options,
            corners
        )
        mActiveBackend = encoder
        encoder.start()
        encoder.sendStatus()
    }


    private fun startEffect() {
        val prefs = Preferences(this)
        val encoder = EffectEncoder(newGate(), buildAppOptions(prefs), EffectConfig.from(prefs))
        mActiveBackend = encoder
        encoder.sendStatus()
    }

    /** Эффект просили не гасить вместе с экраном ТВ. */
    private fun effectStaysOn(): Boolean =
        mCaptureSource == "effect" &&
                Preferences(this).getBoolean(R.string.pref_key_effect_standby)

    private fun notifyTclBlocked() {
        val intent = Intent(BROADCAST_FILTER)
        intent.putExtra(BROADCAST_TAG, false)
        intent.putExtra(BROADCAST_TCL_BLOCKED, true)
        intent.putExtra(BROADCAST_ERROR, "Foreground service blocked by device manufacturer")
        sendStatusBroadcast(intent)
    }

    /**
     * Сервис, поднятый через startForegroundService, обязан выйти в foreground. Если прошивка
     * этого не дала (TCL и похожие запрещают startForeground), Android сам останавливает такой
     * сервис через 10 секунд и следом поднимает ANR. Останавливаемся сразу: от платформы
     * остаётся только исключение о невызванном startForeground, его гасит AmbilightApplication,
     * а подсказку по TCL MainActivity уже получила из notifyTclBlocked.
     */
    private fun stopWithoutForeground(): Int {
        Log.w(TAG, "Foreground start is blocked, stopping before the platform timeout")
        stopSelf()
        return START_NOT_STICKY
    }

    private fun haltStartup() {
        mStartInProgress = false
        // Пробуем выйти в foreground, чтобы показать ошибку, но не падаем, если это запрещено
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this, NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not start foreground during halt: " + e.message)
        }

        notifyActivity()

        shutDownHyperionThread()

        stopSelf()
    }

    /**
     * Гасит HyperionThread вместе с его executor'ами и клиентом. Один interrupt() здесь
     * не работает: после успешного подключения run() уже завершён, и без disconnect()
     * каждый неудачный старт оставлял бы два неубиваемых потока, а клиент Adalight —
     * занятый USB-порт до конца процесса. disconnect() блокирует (awaitTermination,
     * закрытие порта), поэтому уводится с вызывающего потока.
     *
     * С [fadeOut] перед отключением уходят несколько чёрных кадров: подсветку выключили,
     * а не перезапускают.
     */
    private fun shutDownHyperionThread(fadeOut: Boolean = false) {
        val threads = listOfNotNull(mHyperionThread) + mExtraOutputs.values.map { it.thread }
        mHyperionThread = null
        mExtraOutputs.clear()
        mOutput = null
        if (threads.isEmpty()) return
        threads.forEach { it.interrupt() }
        Thread({
            if (fadeOut) {
                repeat(FADE_OUT_FRAMES) {
                    SystemClock.sleep(FADE_OUT_STEP_MS)
                    threads.forEach { it.receiver.clear() }
                }
            }
            threads.forEach { closeOutput(it) }
        }, "hyperion-shutdown").apply { isDaemon = true }.start()
    }

    private fun buildExitButton(): Intent {
        val notificationIntent = Intent(this, this.javaClass)
        notificationIntent.flags = Intent.FLAG_RECEIVER_FOREGROUND
        notificationIntent.action = ACTION_EXIT
        return notificationIntent
    }

    val notification: Notification
        get() {
            val mgr = mNotificationManager
                ?: (getSystemService(NOTIFICATION_SERVICE) as? NotificationManager)
            if (mgr == null) {
                throw IllegalStateException("NotificationManager is null")
            }
            val notification = AppNotification(this, mgr)
            val label = getString(R.string.notification_exit_button)
            notification.setAction(NOTIFICATION_EXIT_INTENT_ID, label, buildExitButton())
            return notification.buildNotification()
        }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private fun startScreenRecord(intent: Intent) {
        if (DEBUG) Log.v(TAG, "Starting screen recorder")
        val projectionManager = mMediaProjectionManager
        if (projectionManager == null) {
            Log.e(TAG, "MediaProjectionManager is null; cannot start screen recording")
            mStartError = resources.getString(R.string.error_media_projection_denied)
            haltStartup()
            return
        }
        val thread = mHyperionThread
        if (thread == null) {
            Log.e(TAG, "HyperionThread is null; cannot start screen recording")
            mStartError = resources.getString(R.string.error_server_unreachable)
            haltStartup()
            return
        }
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)

        // По возможности берём переданный интент проекции напрямую — так надёжнее на устройствах с ограничениями
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        // Сохраняем данные проекции, чтобы восстановиться после сна телевизора
        if (resultData != null) {
            saveProjectionData(resultCode, resultData.extras)
        } else {
            // Запасной путь для старых версий и неожиданных вызовов
            saveProjectionData(resultCode, intent.extras)
        }

        val projectionDataIntent = buildProjectionDataIntent()
        val projectionIntent = resultData ?: projectionDataIntent ?: intent

        val projection = projectionManager.getMediaProjection(
            resultCode,
            projectionIntent
        )
        val window = getSystemService(WINDOW_SERVICE) as WindowManager

        if (projection != null && window != null) {
            sMediaProjection = projection
            val metrics = DisplayMetrics()
            window.defaultDisplay.getRealMetrics(metrics)

            val prefs = Preferences(this)
            val options = buildAppOptions(prefs)

            if (DEBUG) Log.v(
                TAG,
                "Creating encoder: " + metrics.widthPixels + "x" + metrics.heightPixels
            )
            val encoder = ScreenEncoder(
                newGate(),
                projection,
                metrics.widthPixels,
                metrics.heightPixels,
                metrics.densityDpi,
                options
            )
            mActiveBackend = encoder
            encoder.sendStatus()
        } else {
            if (projection == null) {
                Log.e(
                    TAG,
                    "MediaProjection is null (resultCode=$resultCode). Permission likely missing/invalid."
                )
                mStartError = resources.getString(R.string.error_media_projection_denied)
                AnalyticsHelper.logServiceError(
                    baseContext,
                    "media_projection_null",
                    "resultCode: $resultCode"
                )
                haltStartup()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun startAlternativeRecord(method: String) {
        if (DEBUG) Log.v(TAG, "Starting alternative recorder: $method")
        val thread = mHyperionThread
        if (thread == null) {
            Log.e(TAG, "HyperionThread is null; cannot start recording")
            mStartError = resources.getString(R.string.error_server_unreachable)
            haltStartup()
            return
        }
        val window = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        window.defaultDisplay.getRealMetrics(metrics)

        val prefs = Preferences(this)
        val options = buildAppOptions(prefs)

        if (method == "accessibility") {
            val accessibilityService = AccessibilityCaptureService.getInstance()
            if (accessibilityService != null) {
                if (DEBUG) Log.v(TAG, "Creating Accessibility encoder")
                val encoder = AccessibilityEncoder(
                    accessibilityService,
                    newGate(),
                    metrics.widthPixels,
                    metrics.heightPixels,
                    options
                )
                mActiveBackend = encoder
                encoder.sendStatus()
            } else {
                Log.e(TAG, "Accessibility Service not connected!")
                mStartError = "Accessibility Service not enabled"
                haltStartup()
            }
            return
        }

        if (method == "adb_local") {
            val adbPort = prefs.getString(R.string.pref_key_adb_port, "5555")?.toIntOrNull() ?: 5555
            if (DEBUG) Log.v(TAG, "Creating ADB encoder on port $adbPort")
            val encoder = AdbEncoder(
                this.applicationContext,
                newGate(),
                metrics.widthPixels,
                metrics.heightPixels,
                options,
                adbPort
            )
            mActiveBackend = encoder
            encoder.sendStatus()
            return
        }

        if (method == "adb_stream") {
            val adbPort = prefs.getString(R.string.pref_key_adb_port, "5555")?.toIntOrNull() ?: 5555
            if (DEBUG) Log.v(TAG, "Creating screenrecord (H.264 stream) encoder on port $adbPort")
            val encoder = ScreenrecordEncoder(
                this.applicationContext,
                newGate(),
                metrics.widthPixels,
                metrics.heightPixels,
                options,
                adbPort,
                onFatalError = { errorMsg ->
                    // Колбэк приходит из потока энкодера — состояние сервиса и
                    // startForeground трогаем только с главного
                    mHandler?.post {
                        mStartError = errorMsg
                        haltStartup()
                    }
                }
            )
            mActiveBackend = encoder
            encoder.sendStatus()
            return
        }

        if (method == "scrcpy") {
            val adbPort = prefs.getString(R.string.pref_key_adb_port, "5555")?.toIntOrNull() ?: 5555
            if (DEBUG) Log.v(TAG, "Creating scrcpy encoder on port $adbPort")
            val encoder = ScrcpyEncoder(
                this.applicationContext,
                newGate(),
                metrics.widthPixels,
                metrics.heightPixels,
                options,
                adbPort,
                onFatalError = { errorMsg ->
                    // Колбэк приходит из потока энкодера — состояние сервиса и
                    // startForeground трогаем только с главного
                    mHandler?.post {
                        mStartError = errorMsg
                        haltStartup()
                    }
                }
            )
            mActiveBackend = encoder
            encoder.sendStatus()
            return
        }

        if (method == "mstar_vss_capture") {
            val encoder = MStarVssCaptureEncoder(
                applicationContext, newGate(), options,
                mOnFatalError = { errorMsg ->
                    mHandler?.post {
                        mStartError = errorMsg
                        haltStartup()
                    }
                }
            )
            mActiveBackend = encoder
            encoder.sendStatus()
            return
        }

        if (method == "mtk_thal_capture") {
            if (DEBUG) Log.v(TAG, "Creating MTK THAL Capture encoder")
            val encoder = MtkThalCaptureEncoder(
                this.applicationContext,
                newGate(),
                metrics.widthPixels,
                metrics.heightPixels,
                options,
                onFatalError = { errorMsg ->
                    // Колбэк приходит из потока энкодера — состояние сервиса и
                    // startForeground трогаем только с главного
                    mHandler?.post {
                        mStartError = errorMsg
                        haltStartup()
                    }
                }
            )
            mActiveBackend = encoder
            encoder.sendStatus()
            return
        }

        val useRoot = method == "screencap_root"
        if (DEBUG) Log.v(TAG, "Creating screencap encoder (root=$useRoot)")
        val encoder = ScreencapEncoder(
            this.applicationContext,
            newGate(),
            metrics.widthPixels,
            metrics.heightPixels,
            options,
            useRoot,
            onFatalError = { errorMsg ->
                mHandler?.post {
                    mStartError = errorMsg
                    haltStartup()
                }
            }
        )
        mActiveBackend = encoder
        encoder.sendStatus()
    }

    private fun saveProjectionData(resultCode: Int, extras: android.os.Bundle?) {
        mProjectionResultCode = resultCode
        if (extras != null) {
            val copy = android.os.Bundle(extras)
            copy.remove(EXTRA_RESULT_CODE)
            mProjectionDataExtras = copy
        }
    }

    private fun buildProjectionDataIntent(): Intent? {
        val extras = mProjectionDataExtras ?: return null
        return Intent().apply { replaceExtras(extras) }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private fun restartEncoderFromSavedProjection() {
        // В режиме screencap восстанавливать нечего — просто возобновляем цикл захвата
        val screencap = mActiveBackend as? ScreencapEncoder
        if (screencap != null) {
            screencap.resumeRecording()
            return
        }
        val resultCode = mProjectionResultCode ?: return
        val projectionIntent = buildProjectionDataIntent() ?: return
        val projectionManager = mMediaProjectionManager ?: return
        val thread = mHyperionThread ?: return

        // Останавливаем старый энкодер без разрыва соединения (важно для keepalive WLED)
        try {
            (mActiveBackend as? ScreenEncoder)?.stopRecordingNoDisconnect()
        } catch (e: Exception) {
            // Систему уже могла забрать проекцию вместе с потрохами энкодера; нам важно
            // только освободить место под новый, поэтому продолжаем в любом случае.
            Log.w(TAG, "Failed to stop the previous encoder before restart", e)
        }
        mActiveBackend = null

        releaseResource()

        try {
            val projection = projectionManager.getMediaProjection(resultCode, projectionIntent)
            val window = getSystemService(WINDOW_SERVICE) as? WindowManager
            if (projection == null || window == null) {
                return
            }

            sMediaProjection = projection
            val metrics = DisplayMetrics()
            window.defaultDisplay.getRealMetrics(metrics)

            val prefs = Preferences(this)
            val options = buildAppOptions(prefs)

            val encoder = ScreenEncoder(
                newGate(),
                projection,
                metrics.widthPixels,
                metrics.heightPixels,
                metrics.densityDpi,
                options
            )
            mActiveBackend = encoder
            encoder.sendStatus()
        } catch (e: Exception) {
            // Токен MediaProjection мог истечь или быть отозван системой; на Android 14+
            // повторное использование согласия запрещено и бросает SecurityException (часть
            // прошивок — IllegalStateException). Падать из приёмника широковещаний нельзя —
            // сообщаем об ошибке и останавливаемся, иначе сервис навсегда завис бы в
            // foreground без захвата.
            Log.e(TAG, "Failed to restart encoder from saved projection: ${e.message}", e)
            mStartError = resources.getString(R.string.error_media_projection_denied)
            mProjectionResultCode = null
            mProjectionDataExtras = null
            releaseResource()
            notifyActivity()
            stopSelf()
            // Старое согласие не годится — просим новое тем же путём, что и при включении ТВ:
            // с выданным через ADB PROJECT_MEDIA диалог подтверждается сам
            if (AutoStart.shouldResume(this)) {
                val app = applicationContext
                mHandler?.postDelayed({ AutoStart.resume(app) }, SESSION_RESTART_DELAY_MS)
            }
        }
    }

    private fun stopAllCapture() {
        mStartInProgress = false
        mHasConnected = false
        mEverConnected = false
        if (DEBUG) Log.v(TAG, "Stopping all capture")
        mReconnectEnabled = false
        sLayoutTestConnected = false
        mLayoutTestEnabled = false
        mLayoutTestOutputOnly = false
        mLayoutTestOutput = ExtraOutputs.MAIN
        stopAppWatch()
        mNotificationManager?.cancel(NOTIFICATION_ID)

        val backend = mActiveBackend
        if (backend != null) {
            if (DEBUG) Log.v(TAG, "Stopping ${backend.javaClass.simpleName}")
            // Прощальные кадры и disconnect энкодер шлёт из своего потока уже после этой
            // функции, когда выход обнулён. Поэтому он отцепляется, а вывод гасится и
            // закрывается здесь: иначе keepalive клиента держал бы ленту зажжённой
            mGate?.attached = false
            mGate = null
            backend.stopRecording()
            mActiveBackend = null
        }
        shutDownHyperionThread(fadeOut = true)

        releaseResource()
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private fun releaseResource() {
        sMediaProjection?.stop()
        sMediaProjection = null
    }

    val isCapturing: Boolean
        get() = mActiveBackend?.isCapturing() == true

    val isCommunicating: Boolean
        get() = isCapturing && mHasConnected

    private fun notifyActivity() {
        // RUNNING означает готовность источника и основного вывода.
        val communicating = isCommunicating
        if (communicating) mStartInProgress = false
        // Тест раскладки без захвата не запуск подсветки: главный экран остаётся «Остановлено»
        val starting = mStartError == null && mStartInProgress && !communicating &&
            !mLayoutTestOutputOnly
        val intent = Intent(BROADCAST_FILTER)
        intent.putExtra(BROADCAST_TAG, communicating)
        intent.putExtra(BROADCAST_STARTING, starting)
        intent.putExtra(BROADCAST_ERROR, mStartError)
        intent.putExtra(BROADCAST_LAYOUT_TEST_CONNECTED, sLayoutTestConnected)
        intent.putExtra(BROADCAST_SLEEP_AT, sSleepAt)
        if (DEBUG) {
            Log.v(
                TAG, "Broadcasting status: communicating=" + isCommunicating +
                        if (mStartError != null) ", error=$mStartError" else ""
            )
        }
        sendStatusBroadcast(intent)
    }

    /**
     * Рассылает состояние сервиса своим же компонентам (активити и плитке быстрых настроек).
     * Пакет проставляется явно, а приёмники регистрируются как RECEIVER_NOT_EXPORTED,
     * поэтому широковещание не выходит за пределы приложения.
     */
    private fun sendStatusBroadcast(intent: Intent) {
        intent.setPackage(packageName)
        sendBroadcast(intent)
    }

    private fun buildAppOptions(prefs: Preferences): AppOptions {
        val opts = AppOptions(
            mHorizontalLEDCount, mVerticalLEDCount, mFrameRate, mSendAverageColor, mCaptureQuality,
            brightness = prefs.getInt(R.string.pref_key_color_brightness, 100),
            contrast = prefs.getInt(R.string.pref_key_color_contrast, 100),
            blackLevel = prefs.getInt(R.string.pref_key_color_black_level, 0),
            whiteLevel = prefs.getInt(R.string.pref_key_color_white_level, 100),
            saturation = prefs.getInt(R.string.pref_key_color_saturation, 100),
            colorProcessingEnabled = prefs.getBoolean(
                R.string.pref_key_color_processing_enabled,
                true
            ),
            brightnessR = prefs.getInt(R.string.pref_key_color_brightness_r, 100),
            brightnessG = prefs.getInt(R.string.pref_key_color_brightness_g, 100),
            brightnessB = prefs.getInt(R.string.pref_key_color_brightness_b, 100),
            gammaR = prefs.getInt(R.string.pref_key_color_gamma_r, 100),
            gammaG = prefs.getInt(R.string.pref_key_color_gamma_g, 100),
            gammaB = prefs.getInt(R.string.pref_key_color_gamma_b, 100),
            borderDetectionEnabled = prefs.getBoolean(
                R.string.pref_key_border_detection_enabled,
                false
            ),
            borderThreshold = prefs.getInt(R.string.pref_key_border_threshold, 18).coerceIn(0, 64),
            borderCheckIntervalFrames = prefs.getInt(R.string.pref_key_border_check_interval, 60)
                .coerceIn(1, 300),
            borderIgnoreSubtitles = prefs.getBoolean(
                R.string.pref_key_border_ignore_subtitles,
                false
            )
        )
        opts.refreshCameraIdleSettings(prefs)
        mActiveOptions = opts
        registerColorPrefsListener()
        return opts
    }

    private fun registerColorPrefsListener() {
        if (mPrefsListener != null) return
        val sharedPrefs = Preferences.defaultSharedPreferences(this)
        val keyBrightness = getString(R.string.pref_key_color_brightness)
        val keyContrast = getString(R.string.pref_key_color_contrast)
        val keyBlack = getString(R.string.pref_key_color_black_level)
        val keyWhite = getString(R.string.pref_key_color_white_level)
        val keySaturation = getString(R.string.pref_key_color_saturation)
        val keyEnabled = getString(R.string.pref_key_color_processing_enabled)
        val keyBr = getString(R.string.pref_key_color_brightness_r)
        val keyBg = getString(R.string.pref_key_color_brightness_g)
        val keyBb = getString(R.string.pref_key_color_brightness_b)
        val keyGr = getString(R.string.pref_key_color_gamma_r)
        val keyGg = getString(R.string.pref_key_color_gamma_g)
        val keyGb = getString(R.string.pref_key_color_gamma_b)
        val keyBorderOn = getString(R.string.pref_key_border_detection_enabled)
        val keyBorderTh = getString(R.string.pref_key_border_threshold)
        val keyBorderIv = getString(R.string.pref_key_border_check_interval)
        val keyBorderSubs = getString(R.string.pref_key_border_ignore_subtitles)
        val colorKeys = setOf(
            keyBrightness, keyContrast, keyBlack, keyWhite, keySaturation, keyEnabled,
            keyBr, keyBg, keyBb, keyGr, keyGg, keyGb
        )
        val borderKeys = setOf(keyBorderOn, keyBorderTh, keyBorderIv, keyBorderSubs)
        // Пороги автосна настраиваются только вживую под камерой, поэтому идут тем же путём
        // «правка во время захвата», что и цветовые настройки.
        val cameraIdleKeys = setOf(
            getString(R.string.pref_key_camera_idle_enabled),
            getString(R.string.pref_key_camera_idle_timeout),
            getString(R.string.pref_key_camera_idle_dark_level),
            getString(R.string.pref_key_camera_idle_motion_level),
            getString(R.string.pref_key_camera_idle_static),
        )
        val outputKeys = OUTPUT_KEYS.map { getString(it) }.toSet()
        val captureKeys = CAPTURE_KEYS.map { getString(it) }.toSet()
        val legacyLayoutKeys = setOf(
            getString(R.string.pref_key_x_led),
            getString(R.string.pref_key_y_led),
            getString(R.string.pref_key_led_start_corner),
            getString(R.string.pref_key_led_direction),
        )
        val sessionKeys = setOf(
            getString(R.string.pref_key_capture_source),
            getString(R.string.pref_key_capture_method)
        )
        val effectKeys = EFFECT_KEYS.map { getString(it) }.toSet()
        val keyExtraOutputs = getString(R.string.pref_key_extra_outputs)
        val keyOutputDelay = getString(R.string.pref_key_output_delay)
        val keyDelayProfiles = getString(R.string.pref_key_delay_profiles)
        val listener =
            android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
                if (key == null) return@OnSharedPreferenceChangeListener
                val prefs = Preferences(this)
                // В Hyperion и протоколах ламп параметры физической ленты скрыты.
                // Их старые значения не должны пересоздавать захват или эффект.
                if (key in legacyLayoutKeys &&
                    !OutputType.of(prefs.getString(R.string.pref_key_connection_type)).supportsLedLayoutTest
                ) return@OnSharedPreferenceChangeListener
                if (key in colorKeys) mActiveOptions?.refreshColorSettings(prefs)
                if (key in borderKeys) mActiveOptions?.refreshBorderSettings(prefs)
                if (key in cameraIdleKeys) mActiveOptions?.refreshCameraIdleSettings(prefs)
                if (key == keyDelayProfiles && mCaptureSource == "screen" && mHyperionThread != null) {
                    // Первая задержка по приложению включает слежение за экраном, удаление
                    // последней - выключает
                    val profiles = prefs.getString(R.string.pref_key_delay_profiles, "")
                    if (DelayProfiles.parse(profiles).isEmpty()) stopAppWatch() else startAppWatch()
                }
                if (key == keyOutputDelay || key == keyDelayProfiles) applyOutputDelay()
                if (key in effectKeys) {
                    (mActiveBackend as? EffectEncoder)?.setConfig(EffectConfig.from(prefs))
                }
                // Остальное вступало в силу только после ручного перезапуска подсветки; с
                // телефона правят посреди фильма, и ждать перезапуска там некому
                val output = key in outputKeys
                val capture = key in captureKeys
                val session = key in sessionKeys
                val extra = ExtraOutputs.isOutputKey(key)
                if (output || capture || session || extra) {
                    mPendingOutputRestart = mPendingOutputRestart || output
                    mPendingCaptureRestart = mPendingCaptureRestart || capture
                    mPendingSessionRestart = mPendingSessionRestart || session
                    mPendingExtraSync = mPendingExtraSync || extra
                    mHandler?.removeCallbacks(mApplySettings)
                    // Удалённый контроллер ждать незачем: его ключи стёрты, и за паузу клиент
                    // успел бы послать кадры по раскладке из умолчаний
                    val delay = if (key == keyExtraOutputs) 0L else APPLY_SETTINGS_DELAY_MS
                    mHandler?.postDelayed(mApplySettings, delay)
                }
            }
        sharedPrefs.registerOnSharedPreferenceChangeListener(listener)
        mPrefsListener = listener
    }

    private fun applyPendingSettings() {
        AnalyticsHelper.syncCrashlyticsContext(this)
        val session = mPendingSessionRestart
        val capture = mPendingCaptureRestart
        val output = mPendingOutputRestart
        val extra = mPendingExtraSync
        mPendingSessionRestart = false
        mPendingCaptureRestart = false
        mPendingOutputRestart = false
        mPendingExtraSync = false
        if (mActiveBackend == null || mHyperionThread == null) return

        when {
            session -> restartSession()
            capture -> {
                // Сначала энкодер: ему нужен живой HyperionThread, а restartOutput обнуляет его
                // до конца пересоздания. Шлюз нового энкодера сам подхватит новый вывод
                restartCapture()
                if (output) restartOutput()
            }

            output -> restartOutput()
        }
        // Перезапуск сессии и вывода сами приводят контроллеры к настройкам
        if (extra && !session && !output) syncExtraOutputs()
    }

    /**
     * Новый способ или источник захвата — это другой тип foreground-сервиса и, возможно,
     * новое согласие. Честнее перезапустить подсветку целиком тем же путём, что и кнопка.
     */
    private fun restartSession() {
        Log.i(TAG, "Capture source or method changed, restarting the session")
        stopAllCapture()
        stopSelf()
        val app = applicationContext
        mHandler?.postDelayed({ CaptureLauncher.start(app) }, SESSION_RESTART_DELAY_MS)
    }

    /** Пересоздаёт потоки вывода под работающим энкодером. */
    private fun restartOutput() {
        val oldPrimary = mHyperionThread ?: return
        Log.i(TAG, "Connection settings changed, restarting the output")
        mStartInProgress = true
        mHasConnected = false
        notifyActivity()
        mOutput = null
        mHyperionThread = null
        oldPrimary.interrupt()
        Thread({
            // Старый вывод закрываем до нового: Adalight заново открывает тот же USB-порт
            closeOutput(oldPrimary)
            mHandler?.post {
                // Пока закрывался старый вывод, подсветку могли выключить
                if ((mActiveBackend == null && !mLayoutTestOutputOnly) ||
                    mHyperionThread != null) return@post
                // Новые настройки проверяются как при старте: при ошибке — тот же текст и остановка
                mHasConnected = false
                if (!prepared(outputOnly = mLayoutTestOutputOnly)) haltStartup()
            }
        }, "hyperion-restart").apply { isDaemon = true }.start()
    }

    /** Пересоздаёт энкодер с новыми частотой, качеством и числом светодиодов. */
    private fun restartCapture() {
        val backend = mActiveBackend ?: return
        val prefs = Preferences(this)
        mFrameRate = prefs.getInt(R.string.pref_key_framerate)
        mCaptureQuality = prefs.getString(R.string.pref_key_capture_quality, "128")
            ?.toIntOrNull() ?: 128
        mHorizontalLEDCount = prefs.getInt(R.string.pref_key_x_led)
        mVerticalLEDCount = prefs.getInt(R.string.pref_key_y_led)
        mSendAverageColor = prefs.getBoolean(R.string.pref_key_use_avg_color)
        Log.i(TAG, "Capture settings changed, recreating ${backend.javaClass.simpleName}")

        when (backend) {
            // Эффект не зависит ни от частоты, ни от качества захвата, а раскладку ленты
            // разбор кадра перечитывает сам
            is EffectEncoder -> return

            is ScreenEncoder -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    // Android 14+ не отдаёт вторую проекцию по тому же согласию — новые
                    // параметры захвата вступят в силу при следующем запуске
                    Log.i(TAG, "MediaProjection cannot be reused on this Android, keeping the encoder")
                    return
                }
                restartEncoderFromSavedProjection()
            }

            is CameraEncoder -> {
                mGate?.attached = false
                backend.stopRecordingNoDisconnect()
                mActiveBackend = null
                startCameraCapture()
            }

            else -> {
                mGate?.attached = false
                backend.stopRecording()
                mActiveBackend = null
                val method = prefs.getString(R.string.pref_key_capture_method, "media_projection")
                    ?: "media_projection"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    startAlternativeRecord(method)
                } else {
                    restartSession()
                }
            }
        }
    }

    private fun unregisterColorPrefsListener() {
        val listener = mPrefsListener ?: return
        try {
            Preferences.defaultSharedPreferences(this)
                .unregisterOnSharedPreferenceChangeListener(listener)
        } catch (_: Exception) {
            // Сервис уже останавливается; если SharedPreferences успели уйти вместе с
            // контекстом, снимать слушателя не с чего.
        }
        mPrefsListener = null
    }

    interface HyperionThreadBroadcaster {
        fun onConnected()
        fun onConnectionError(errorID: Int, error: String?)
        fun onReceiveStatus(isCapturing: Boolean)
    }

    companion object {
        const val BROADCAST_ERROR = "SERVICE_ERROR"
        const val BROADCAST_LAYOUT_TEST_CONNECTED = "LAYOUT_TEST_CONNECTED"
        @Volatile
        var sLayoutTestConnected = false
            private set
        const val BROADCAST_TAG = "SERVICE_STATUS"
        const val BROADCAST_STARTING = "SERVICE_STARTING"
        const val BROADCAST_FILTER = "SERVICE_FILTER"
        const val BROADCAST_TCL_BLOCKED = "TCL_BLOCKED"
        const val BROADCAST_SLEEP_AT = "SLEEP_AT"
        private const val DEBUG = false
        private const val TAG = "ScreenGrabberService"

        private const val BASE = "com.vasmarfas.UniversalAmbientLight.service."
        const val ACTION_START = BASE + "ACTION_START"
        const val ACTION_START_CAMERA = BASE + "ACTION_START_CAMERA"
        const val ACTION_START_EFFECT = BASE + "ACTION_START_EFFECT"
        const val ACTION_STOP = BASE + "ACTION_STOP"
        const val ACTION_CLEAR = BASE + "ACTION_CLEAR"
        const val ACTION_LAYOUT_TEST = BASE + "ACTION_LAYOUT_TEST"
        const val EXTRA_LAYOUT_TEST_ENABLED = BASE + "EXTRA_LAYOUT_TEST_ENABLED"
        const val EXTRA_OUTPUT_ID = BASE + "EXTRA_OUTPUT_ID"
        const val ACTION_DETECT_FRAME = BASE + "ACTION_DETECT_FRAME"
        const val ACTION_SLEEP_TIMER = BASE + "ACTION_SLEEP_TIMER"
        const val EXTRA_SLEEP_MINUTES = BASE + "EXTRA_SLEEP_MINUTES"
        const val ACTION_CALIBRATION = BASE + "ACTION_CALIBRATION"
        const val EXTRA_CALIBRATION = BASE + "EXTRA_CALIBRATION"
        const val EXTRA_DARK_MS = BASE + "EXTRA_DARK_MS"
        const val CALIBRATION_BEGIN = "begin"
        const val CALIBRATION_END = "end"
        const val CALIBRATION_DARK = "dark"
        const val ACTION_EXIT = BASE + "ACTION_EXIT"
        const val GET_STATUS = BASE + "ACTION_STATUS"
        const val EXTRA_RESULT_CODE = BASE + "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = BASE + "EXTRA_RESULT_DATA"
        private const val NOTIFICATION_ID = 1
        private const val NOTIFICATION_EXIT_INTENT_ID = 2
        private const val APPLY_SETTINGS_DELAY_MS = 1200L
        private const val SESSION_RESTART_DELAY_MS = 700L
        private const val FADE_OUT_FRAMES = 3
        private const val FADE_OUT_STEP_MS = 100L
        private const val APP_WATCH_INTERVAL_MS = 3000L
        private const val MAX_CALIBRATION_MS = 3 * 60 * 1000L
        private const val MAX_DARK_MS = 6000L

        /** Настройки вывода: меняются пересозданием HyperionThread под тем же энкодером. */
        private val OUTPUT_KEYS = intArrayOf(
            R.string.pref_key_connection_type,
            R.string.pref_key_host,
            R.string.pref_key_port,
            R.string.pref_key_priority,
            R.string.pref_key_reconnect,
            R.string.pref_key_reconnect_delay,
            R.string.pref_key_adalight_baudrate,
            R.string.pref_key_adalight_protocol,
            R.string.pref_key_wled_color_order,
            R.string.pref_key_wled_protocol,
            R.string.pref_key_wled_rgbw,
            R.string.pref_key_wled_brightness,
            R.string.pref_key_smoothing_enabled,
            R.string.pref_key_smoothing_preset,
            R.string.pref_key_settling_time,
            R.string.pref_key_update_frequency,
            R.string.pref_key_ha_token,
            R.string.pref_key_ha_lamps,
            R.string.pref_key_ha_update_interval,
            R.string.pref_key_ha_change_threshold,
            R.string.pref_key_ha_transition,
            R.string.pref_key_ha_brightness_mode,
            R.string.pref_key_ha_brightness,
            R.string.pref_key_ha_dark_off,
            R.string.pref_key_ha_dark_threshold,
            R.string.pref_key_ha_turn_off_lights,
            R.string.pref_key_dmx_universe,
            R.string.pref_key_dmx_leds_per_universe,
            R.string.pref_key_opc_channel,
            R.string.pref_key_hue_username,
            R.string.pref_key_hue_lamps,
            R.string.pref_key_wiz_lamps,
            R.string.pref_key_yeelight_lamps,
            R.string.pref_key_lifx_lamps,
            R.string.pref_key_govee_lamps,
            R.string.pref_key_z2m_lamps,
            R.string.pref_key_hue_clientkey,
            R.string.pref_key_hue_area,
            R.string.pref_key_mqtt_username,
            R.string.pref_key_mqtt_password,
            R.string.pref_key_z2m_base_topic,
            R.string.pref_key_nanoleaf_token,
        )

        /** Параметры эффекта: применяются на ходу, без перезапуска. */
        private val EFFECT_KEYS = intArrayOf(
            R.string.pref_key_effect,
            R.string.pref_key_effect_color,
            R.string.pref_key_effect_color2,
            R.string.pref_key_effect_speed,
            R.string.pref_key_effect_brightness,
            R.string.pref_key_effect_temperature,
            R.string.pref_key_led_start_corner,
            R.string.pref_key_led_direction,
        )

        /** Настройки, которые энкодер берёт при создании. */
        private val CAPTURE_KEYS = intArrayOf(
            R.string.pref_key_framerate,
            R.string.pref_key_capture_quality,
            R.string.pref_key_use_avg_color,
            R.string.pref_key_adb_port,
            R.string.pref_key_x_led,
            R.string.pref_key_y_led,
        )

        private var sMediaProjection: MediaProjection? = null

        /** Проблема в настройках, из-за которой захват не начнётся. */
        data class SettingsError(
            val code: String,
            val message: String,
            val details: String? = null,
        )

        /**
         * Проверяет настройки, без которых сервису нечего отправлять, чтобы предупредить
         * пользователя сразу, а не после всех диалогов с разрешениями. Возвращает null,
         * когда настройки пригодны.
         */
        @JvmStatic
        fun validateSettings(context: Context): SettingsError? =
            validateOutput(context, Preferences(context))

        /** Та же проверка для любого контроллера: [prefs] - его настройки. */
        private fun validateOutput(context: Context, prefs: Preferences): SettingsError? {
            val connectionType =
                prefs.getString(R.string.pref_key_connection_type, "hyperion") ?: "hyperion"
            val type = OutputType.of(connectionType)

            if (type != OutputType.ADALIGHT && !LocalNetworkAccess.isGranted(context)) {
                return SettingsError("local_network", context.getString(R.string.error_local_network))
            }

            // Адрес не нужен USB, лампам со своими адресами и E1.31 (без него - мультикаст)
            if (type.needsHost) {
                val host = prefs.getString(R.string.pref_key_host, null)?.trim()
                if (host.isNullOrEmpty() || host == "0.0.0.0") {
                    return SettingsError(
                        "empty_host",
                        context.getString(R.string.error_empty_host)
                    )
                }
                val port = prefs.getInt(R.string.pref_key_port, -1)
                // Мосту Hue порт не задаётся, в настройках его поля нет
                if (type.defaultPort > 0 && port == -1) {
                    return SettingsError(
                        "empty_port",
                        context.getString(R.string.error_empty_port)
                    )
                }
                // Порт должен попадать в диапазон 1-65535
                if (type.defaultPort > 0 && (port < 1 || port > 65535)) {
                    return SettingsError(
                        "invalid_port",
                        context.getString(R.string.error_invalid_port, port),
                        "port: $port"
                    )
                }
            }

            if (type == OutputType.HUE && prefs.getString(R.string.pref_key_hue_username, "").isNullOrBlank()) {
                return SettingsError("hue_not_paired", context.getString(R.string.error_hue_not_paired))
            }
            if (type == OutputType.NANOLEAF &&
                prefs.getString(R.string.pref_key_nanoleaf_token, "").isNullOrBlank()
            ) {
                return SettingsError("nanoleaf_not_paired", context.getString(R.string.error_nanoleaf_not_paired))
            }
            val hueArea = type == OutputType.HUE && !prefs.getString(R.string.pref_key_hue_area, "").isNullOrBlank()
            if (hueArea && prefs.getString(R.string.pref_key_hue_clientkey, "").isNullOrBlank()) {
                return SettingsError("hue_no_clientkey", context.getString(R.string.error_hue_no_clientkey))
            }
            val lampsKey = type.lampsKey
            if (lampsKey != null && type != OutputType.HOME_ASSISTANT && !hueArea &&
                HomeAssistantLamp.parseList(prefs.getString(lampsKey, "")).isEmpty()
            ) {
                return SettingsError("no_lamps", context.getString(R.string.error_no_lamps))
            }

            if ("homeassistant".equals(connectionType, ignoreCase = true)) {
                val token = prefs.getString(R.string.pref_key_ha_token, "")?.trim() ?: ""
                if (token.isEmpty()) {
                    return SettingsError(
                        "ha_token_missing",
                        context.getString(R.string.error_ha_token_missing)
                    )
                }
                val lamps =
                    HomeAssistantLamp.parseList(prefs.getString(R.string.pref_key_ha_lamps, ""))
                if (lamps.isEmpty()) {
                    return SettingsError(
                        "ha_no_lamps",
                        context.getString(R.string.error_ha_no_lamps)
                    )
                }
            }

            // Ленты используют адресную раскладку; Hyperion, Nanoleaf и зональные
            // лампы не должны зависеть от сохранённых параметров физических LED.
            if (type.supportsLedLayoutTest) {
                val layout = LedLayout.from(prefs)
                if (layout.configuredLedCount() <= 0) {
                    return SettingsError(
                        "invalid_led_counts",
                        context.getString(R.string.error_invalid_led_counts),
                        "top: ${layout.topLed}, right: ${layout.rightLed}, " +
                                "bottom: ${layout.bottomLed}, left: ${layout.leftLed}, " +
                                "x: ${layout.xLed}, y: ${layout.yLed}"
                    )
                }
            }

            return null
        }

        /**
         * Подсветка не запустилась ещё до сервиса (отказ в согласии на запись экрана), и
         * сказать об этом экранам и телефону-пульту, кроме нас, некому.
         */
        @JvmStatic
        fun notifyNotStarted(context: Context, error: String) {
            val intent = Intent(BROADCAST_FILTER)
            intent.putExtra(BROADCAST_TAG, false)
            intent.putExtra(BROADCAST_STARTING, false)
            intent.putExtra(BROADCAST_ERROR, error)
            intent.setPackage(context.packageName)
            context.sendBroadcast(intent)
        }

        /** Когда сработает таймер сна, мс по часам устройства; 0 - таймера нет. */
        @Volatile
        @JvmStatic
        var sSleepAt: Long = 0L
            private set

        /** True, пока экземпляр сервиса жив (onCreate→onDestroy). */
        @Volatile
        @JvmStatic
        var sInstanceRunning: Boolean = false
            internal set
    }
}
