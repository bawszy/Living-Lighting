package com.vasmarfas.UniversalAmbientLight.ui.home

import android.content.Context
import com.vasmarfas.UniversalAmbientLight.R
import com.vasmarfas.UniversalAmbientLight.common.effect.Effect
import com.vasmarfas.UniversalAmbientLight.common.network.HomeAssistantLamp
import com.vasmarfas.UniversalAmbientLight.common.network.OutputType
import com.vasmarfas.UniversalAmbientLight.common.util.ExtraOutputs
import com.vasmarfas.UniversalAmbientLight.common.util.Preferences
import com.vasmarfas.UniversalAmbientLight.ui.devices.titleRes
import com.vasmarfas.UniversalAmbientLight.ui.effects.titleRes

/** Куда уходит свет: «WLED · 192.168.1.50:19446». */
internal fun describeTarget(context: Context, prefs: Preferences): String {
    val type = OutputType.of(prefs.getString(R.string.pref_key_connection_type))
    return "${context.getString(type.titleRes())} · ${describeAddress(context, prefs)}"
}

/** Вторая часть [describeTarget]: адрес, а у ламп и USB то, что его заменяет. */
internal fun describeAddress(context: Context, prefs: Preferences): String {
    val type = OutputType.of(prefs.getString(R.string.pref_key_connection_type))
    val host = prefs.getString(R.string.pref_key_host)?.trim().orEmpty()
    val lampsKey = type.lampsKey
    return when {
        type == OutputType.ADALIGHT -> "USB"
        lampsKey != null && !type.needsHost -> {
            val lamps = HomeAssistantLamp.parseList(prefs.getString(lampsKey, "")).size
            context.getString(R.string.devices_lamps_count, lamps)
        }

        type == OutputType.HUE && !prefs.getString(R.string.pref_key_hue_area).isNullOrBlank() ->
            prefs.getString(R.string.pref_key_hue_area_name).orEmpty().ifBlank { host }

        host.isEmpty() && type == OutputType.E131 -> context.getString(R.string.home_target_multicast)
        host.isEmpty() -> context.getString(R.string.home_target_no_host)
        type.defaultPort == 0 || type == OutputType.HOME_ASSISTANT -> host
        else -> "$host:${prefs.getInt(R.string.pref_key_port)}"
    }
}

/** То же для главного экрана: основной контроллер и сколько включено рядом с ним. */
internal fun describeTargets(context: Context, prefs: Preferences): String {
    val main = describeTarget(context, prefs)
    val extra = ExtraOutputs.ids(prefs).count {
        prefs.forOutput(it).getBoolean(R.string.pref_key_output_enabled)
    }
    return if (extra == 0) main else context.getString(R.string.home_target_with_extra, main, extra)
}

/** Как подписать дополнительный контроллер: своё имя, а без него - адрес. */
internal fun describeOutput(context: Context, prefs: Preferences): String =
    prefs.getString(R.string.pref_key_output_name)?.trim().orEmpty()
        .ifEmpty { describeTarget(context, prefs) }

/**
 * Чего не хватает, чтобы подсветке было куда светить; null - контроллер настроен.
 * Проверяет то же, что сервис перед запуском, но отвечает коротко, для главного экрана.
 */
internal fun setupIssue(context: Context, prefs: Preferences): String? {
    val type = OutputType.of(prefs.getString(R.string.pref_key_connection_type))
    fun blank(key: Int) = prefs.getString(key).isNullOrBlank()
    val lampsKey = type.lampsKey
    val hueArea = type == OutputType.HUE && !blank(R.string.pref_key_hue_area)
    return when {
        type.needsHost && blank(R.string.pref_key_host) -> context.getString(R.string.home_setup_no_host)
        type == OutputType.HUE && blank(R.string.pref_key_hue_username) ||
                type == OutputType.NANOLEAF && blank(R.string.pref_key_nanoleaf_token) ->
            context.getString(R.string.home_setup_not_paired, context.getString(type.titleRes()))

        type == OutputType.HOME_ASSISTANT && blank(R.string.pref_key_ha_token) ->
            context.getString(R.string.home_setup_no_token)

        hueArea && blank(R.string.pref_key_hue_clientkey) -> context.getString(R.string.home_setup_hue_repair)
        lampsKey != null && !hueArea && HomeAssistantLamp.parseList(prefs.getString(lampsKey, "")).isEmpty() ->
            context.getString(R.string.home_setup_no_lamps)

        else -> null
    }
}

/** Откуда берётся картинка: камера, эффект или способ захвата экрана без технических хвостов. */
internal fun describeSource(context: Context, prefs: Preferences): String {
    val source = prefs.getString(R.string.pref_key_capture_source) ?: "screen"
    if (source == "effect") {
        val effect = Effect.byId(prefs.getString(R.string.pref_key_effect))
        return context.getString(R.string.home_source_effect, context.getString(effect.titleRes()))
    }
    if (source == "camera") {
        return entryFor(
            context,
            R.array.pref_list_capture_source,
            R.array.pref_list_capture_source_values,
            source
        )
    }
    val method = prefs.getString(R.string.pref_key_capture_method) ?: "media_projection"
    // В списке методов рядом с названием задержка и звёзды — на главном экране они лишние
    return entryFor(
        context,
        R.array.pref_list_capture_method,
        R.array.pref_list_capture_method_values,
        method
    ).substringBefore(" (")
}

private fun entryFor(context: Context, entriesRes: Int, valuesRes: Int, value: String): String {
    val values = context.resources.getStringArray(valuesRes)
    val entries = context.resources.getStringArray(entriesRes)
    return entries.getOrNull(values.indexOf(value)) ?: value
}
