package com.vasmarfas.UniversalAmbientLight.common.studio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StudioV2Test {
    @Test fun `confirmed living room layout has three independent zones and 389 pixels`() {
        val config = StudioConfig()
        assertEquals(389, config.total)
        assertNull(config.error())
        assertEquals(listOf(0 to 240, 240 to 354, 354 to 389),
            config.segments.map { it.start to it.stop })
    }
    @Test fun `31 modes create RGB with no invalid channels`() {
        assertEquals(31, StudioEffects.modes.distinct().size)
        StudioEffects.modes.forEach { mode ->
            (0 until 389).forEach { pixel ->
                val value = StudioEffects.pixel(mode, pixel, 389, 12345L,
                    0xFF6600, 0x1269FF, 50, 60)
                if (mode == "screen") assertNull(value)
                else {
                    assertNotNull(value)
                    assertTrue(value!!.all { it in 0..255 })
                }
            }
        }
    }
    @Test fun `black frame diagnostics find black and white`() {
        val blank = StudioFrameMonitor.inspect(ByteArray(120 * 3), 10, 12, 100L)
        assertEquals(100, blank.blackPercent)
        val lit = StudioFrameMonitor.inspect(ByteArray(120 * 3) { 255.toByte() }, 10, 12, 200L)
        assertEquals(0, lit.blackPercent)
    }
    @Test fun `unrecognized mode and overlapping physical ranges are rejected`() {
        assertNotNull(StudioConfig(5, listOf(
            StudioSegment(1,"bad", 0, 5, mode="fake")
        )).error())
        assertNotNull(StudioConfig(5, listOf(
            StudioSegment(1,"one", 0, 3), StudioSegment(2,"two", 2, 5)
        )).error())
        assertNull(StudioConfig(5, listOf(
            StudioSegment(1,"one", 0, 3), StudioSegment(2,"two", 3, 5)
        )).error())
    }
}
