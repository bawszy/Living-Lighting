package com.vasmarfas.UniversalAmbientLight.common.studio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class StudioMapperTest {
    private fun frame(vararg rgb: Int): ByteArray = rgb.map { it.toByte() }.toByteArray()

    @Test fun `two screen maps become one ordered LED stream`() {
        val config = StudioConfig(6, listOf(
            StudioSegment(1, "left shelf", 0, 2, left = 0, right = 50, mapping = "average", smoothing = 0),
            StudioSegment(2, "right tv", 2, 4, left = 50, right = 100, mapping = "average", smoothing = 0)
        ))
        val frame = frame(255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 0)
        val output = StudioMapper().render(config, frame, 4, 1)
        assertEquals(6, output.size)
        assertEquals(127, output[0].red)
        assertEquals(0, output[0].blue)
        assertEquals(127, output[2].blue) // right half: blue + yellow, averaged
        assertEquals(0, output[4].red) // uncovered LEDs off
        assertEquals(0, output[5].green)
    }

    @Test fun `each physical pixel receives its independent screen sample`() {
        val config = StudioConfig(4, listOf(
            StudioSegment(1, "a", 0, 4, mapping = "horizontal", smoothing = 0)
        ))
        val output = StudioMapper().render(config,
            frame(255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 255), 4, 1)
        assertEquals(255, output[0].red)
        assertEquals(255, output[1].green)
        assertEquals(255, output[2].blue)
        assertEquals(255, output[3].red)
        assertEquals(255, output[3].green)
    }

    @Test fun `reverse swaps LED sampling order`() {
        val segment = StudioSegment(1, "reverse", 0, 2, reverse = true, smoothing = 0)
        val output = StudioMapper().render(StudioConfig(2, listOf(segment)),
            frame(255, 0, 0, 0, 0, 255), 2, 1)
        assertEquals(255, output[0].blue)
        assertEquals(255, output[1].red)
    }

    @Test fun `physical overlap rejected but screen overlap allowed`() {
        val a = StudioSegment(1, "a", 0, 2)
        val b = StudioSegment(2, "b", 2, 4)
        assertNull(StudioConfig(4, listOf(a, b)).error())
        assertNotNull(StudioConfig(4, listOf(a, b.copy(start = 1))).error())
    }

    @Test fun `selected test lights exactly one segment`() {
        val config = StudioConfig(4, listOf(
            StudioSegment(1, "shelf", 0, 2), StudioSegment(2, "tv", 2, 4)))
        val output = StudioMapper().render(config, frame(0, 0, 0), 1, 1, testId = 2)
        assertEquals(0, output[0].red)
        assertEquals(255, output[2].red)
        assertEquals(255, output[3].blue)
    }
}
