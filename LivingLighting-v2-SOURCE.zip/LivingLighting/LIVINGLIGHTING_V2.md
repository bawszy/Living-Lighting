# LivingLighting — Version 2 personal fork

**Status:** Source upgrade + core tests. NOT a new compiled or Fire TV-tested APK. The prior beta APK is NOT this version. The current environment has no Android SDK/Gradle distribution or internet access, so I cannot honestly mark the Android build as verified.

## Based on working Universal Ambient Light capture

- The capture implementation, capture settings, permission and service flow, network controller connection, and standard settings UI remain from the original Universal Ambient Light source (2.2.0).
- A distinct application ID (`com.cj.livinglighting`) means the official Universal Ambient Light installation is untouched.
- All added custom-mapping features are **disabled by default**. Switch them on only after confirming the original capture is working in LivingLighting.
- Your confirmed WLED setup: 389 LEDs, output GPIO16 length 354 and GPIO2 length 35 (as shown on your screenshot). Logical ranges: shelves 1–240, TV 241–354, lamp 355–389. No wiring change.

## What's new in v2

- Redesigned dark widescreen control screen with two-pane layout for a TV and stacked layout for smaller screens.
- Independent, editable WLED-style LED segments, up to 64 active zones with non-overlapping **physical** indices. TV screen source rectangles may overlap freely.
- Split/add/delete/disable segments; individual start, end, reverse, colour, speed, intensity, brightness, saturation and temporal smoothing.
- Full-screen, upper-right, left-half, right-half, centre and other one-click screen sampling presets, plus editable percentage bounds.
- 8 screen sampling layouts: average, horizontal, vertical, perimeter, left, right, top, bottom.
- **31 local modes** including screen sync and off. The effect modes are implemented within this app; they are NOT guaranteed to match the WLED firmware's similarly named effects. All effects run while the capture processing loop runs.
- Two hex effect colours instead of decimal RGB numbers.
- Named saved scenes and segment identification (white light on selected LEDs while capture runs).
- Read-only capture diagnostics with dark-pixel percentage, frame count and frame dimensions.
- Optional hold-last-colour-on-black toggle. **Off by default**. It can freeze lights during genuinely dark scenes, so it does not unlock protected video.
- Reversible, opt-in capture trial presets: low overhead (15fps/64px), balanced (30fps/128px), more detail (30fps/256px), fast response (60fps/128px). Captures your original FPS/quality values on the first trial and restores the exact values or absence of values. Requires restarting capture to judge results. The existing capture method and permissions are untouched.

## What these settings CANNOT solve

Netflix/Prime/Disney+ use DRM-protected video surfaces which normal Fire OS screen capture cannot read. Changing FPS or resolution, enabling accessibility, and watching black-frame diagnostics are NOT bypasses and cannot guarantee video from any particular app. Some ordinary video overlays can likewise remain hidden. No claim of all-service compatibility is made.

## Build an installable APK

The source is a Gradle Android project requiring an internet-connected Mac or build environment, JDK 17, Android SDK platform 37, Android NDK 27.2, and the matching Gradle wrapper. Use:

```
./gradlew :app:assembleFullDebug
```

The APK, if the build succeeds, is at `app/build/outputs/apk/full/debug/app-full-debug.apk`.

A `GitHub Actions` build workflow is included at `.github/workflows/livinglighting-apk.yml` for an alternative that needs no Android Studio on your machine. Place the contents of `ual-source/` at the root of a private GitHub repository, open **Actions → LivingLighting - Personal APK → Run workflow**, and download the APK from the workflow's **Artifacts**. That workflow itself has not been executed or verified in this environment.

### Installation

- The previous LivingLighting Beta 1 APK and the v2 debug build might be signed with different keys. If Android says **App not installed** because of conflicting signatures, **uninstall only LivingLighting**, NOT Universal Ambient Light, before installing v2. This resets LivingLighting-only settings.
- Keep your working Universal Ambient Light installation as backup.
- Stop Universal Ambient Light's screen capture before using LivingLighting to avoid both sending conflicting packets to WLED.
- On Fire TV: use Downloader to open a **direct, trusted APK file URL**, not a web page that merely displays an attachment.

## Testing done in the current environment

- Kotlin/JVM exercise of **all 31 effects × 389 LEDs × 4 timestamps**, checking valid RGB output.
- Studio core compiled with local stubs for Android preferences and JSON; mapping boundaries, overlaps, segment test and black-frame hold verified.
- Capture trials tested for preserving previously configured values (including no stored value) after multiple trials.
- Compose UI has been syntax-parsed using Kotlin, but **cannot be type-checked or built without Android/Compose dependencies**. A real Fire TV test is necessary to check focus, navigation, USB/network permissions, capture prompts, app startup and long-run stability.

## Copyright and licence

This is a personal, noncommercial fork of Universal Ambient Light under PolyForm Noncommercial 1.0.0. The original `LICENSE.txt` and `THIRD_PARTY_LICENSES.md` are preserved. Any commercial deployment requires permission from the original author.
