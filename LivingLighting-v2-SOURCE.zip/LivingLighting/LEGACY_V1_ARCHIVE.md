# CJ Ambient Studio — Fire TV custom mapping fork

This is a **noncommercial personal fork** of [Universal Ambient Light](https://github.com/vasmarfas/universal-ambient-light), version 2.2.0. The original project's copyright, [PolyForm Noncommercial 1.0.0 licence](LICENSE.txt), and [third-party licences](THIRD_PARTY_LICENSES.md) remain in the archive. The custom installation has its own Android application ID, `com.cj.ambientstudio`, so it does **not** replace the working Universal Ambient Light installation.

## Added in this build

- **Settings → Ambient Studio → Independent LED segments** (Fire TV remote-friendly).
- Any physical start/stop LED range (displayed **1-based and inclusive**), up to 64 independent non-overlapping enabled segments.
- A separately adjustable screen sampling rectangle for each segment (left, right, top, bottom in percent) and a live rectangle preview.
- Mapping options: one averaged colour, horizontal individual samples, vertical individual samples, and perimeter sampling, plus reverse order.
- Per-segment brightness, saturation and smoothing.
- Segment modes: screen sync, solid, rainbow, breathing, gradient, comet and off. Animations update while the capture engine is running.
- Split, add, delete, enable/disable and test LED ranges; named preset save/load/delete.
- A single WLED DDP or UDP-raw output frame containing the combined 389 LED colours. No MacBook, second controller, helper app or wiring change is required after successful installation.

## Initial settings for this home installation

The original hardware screenshot shows WLED with **389 LEDs**, configured as 354 LEDs on GPIO16 and 35 LEDs on GPIO2, in GRB order. This fork starts with the following editable logical mapping:

| Segment | Physical LED numbers | Zero-based indices | Mode |
| --- | --- | --- | --- |
| Shelves | 1–240 | 0–239 | Perimeter screen sampling |
| TV | 241–354 | 240–353 | Perimeter screen sampling |
| Lamp | 355–389 | 354–388 | Whole-screen average |

These are **editable defaults**, not verified physical orientation mappings. Use **Split selected segment** to divide the shelves into right/bottom/left shelves or arbitrary ten-LED pieces. The visual test lights only the selected range white while capture is running, so orientation can be calibrated without rewiring.

## Installation and first use

1. Leave your current Universal Ambient Light app installed as a fallback. **Stop its capture** before starting Ambient Studio, since both apps would otherwise send competing data to the same WLED controller.
2. Build the `fullDebug` Android APK in Android Studio or via `./gradlew :app:assembleFullDebug`. The expected output is `app/build/outputs/apk/full/debug/app-full-debug.apk`. Use the provided APK if an artifact accompanies this source archive.
3. Enable ADB debugging on your Fire TV and install using `adb install -r app-full-debug.apk`, or sideload the APK with Downloader from a trusted local URL.
4. In Ambient Studio, select your WLED controller in **Settings → Connection**. The previously shown local IP was `192.168.1.113`; verify it in WLED/your router because DHCP addresses can change. Select **WLED / DDP** and keep the original capture method that works on your Fire Stick.
5. In **Settings → Ambient Studio → Independent LED segments**, check **Total LEDs = 389**, press **Save mapping**, then enable **Custom mapping**. As you edit, save to apply. Individual source rectangles may overlap; physical LED ranges may not.
6. Run video in a known-working app such as YouTube, start capture, then adjust each segment and use the selected LED test when needed. Turn the test off when finished.

## Scope and known limitations

- **Status:** source-level implementation requiring an APK build and a real Fire TV test before being considered a production release. The original app's screen capture, Fire OS permissions, decoder restrictions and existing effects interface remain unchanged.
- **Netflix/DRM:** this fork cannot access protected streaming frames that Fire OS does not expose.
- The segment effect modes listed above are implemented locally while screen capture is running; this fork does **not** replicate all of WLED's firmware effect library. Real-time DDP output normally takes priority over WLED's native segment effects.
- The custom mapping is applied to the **main WLED/DDP output only**. Do not aim additional outputs at the same WLED IP while using this mode.
- The new segment editor is local to the Fire TV. Existing Universal Ambient Light phone-remote controls and setting backups do not yet include these custom segment settings.
- Power-cycle behavior and Fire OS 8.1 permission prompts depend on your actual Fire TV build. Test startup and sleep/wake before relying on automatic capture.
- Some SDK/Gradle tooling versions are recent; Android Studio may need its current JDK and Android API 37 platform installed. The build has a custom `ndkVersion` because the source project includes optional 32-bit native capture helpers.

## Testing

Run `./gradlew :app:testFullDebugUnitTest` to check boundaries, independent screen areas, reverse order, overlap validation, uncovered LEDs and selected-LED test output. A real Fire TV Stick and WLED ESP32 are still required for end-to-end latency and colour correctness validation.

## Licence

© vasmarfas and contributors for the original app. Portions changed for CJ's personal project. Source is available for **noncommercial use only** under the retained upstream [PolyForm Noncommercial 1.0.0](LICENSE.txt) licence; commercial use requires a separate licence from the original author. Preserve the copyright and licence notices when sharing a modified build.
